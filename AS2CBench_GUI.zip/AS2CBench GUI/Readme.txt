===================================================================================
				AS2CBENCH v.1.0
===================================================================================

AS2CBENCH stands for Accelerated Synthesizable SystemC Benchmark suite.
It is a accelerated version of S2CBENCH .S2CBENCH stands for Synthesizable SystemC 
Benchmark suite.It is a open sourceSystemC benchmarks created to help designers evaluate 
the QoR of state of the art HLS Tools. 

Most of the work has been done by the DARClab at the Hong Kong Polytechnic Universities
Department of Electronic and Information Engineering (EIE) 
DARClab =Design Automation and Reconfigurable Computing Laboratory - www.eie.polyu.edu.hk/~schaferb/darclab


AS2CBench is distributed in the hope that it will be useful. AS2CBench is free software and hardware; 
you can redistribute it and/or modify it, but please remember but WITHOUT ANY WARRANTY; without even the 
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

AS2CBENCH includes the following Testcases:

------------------------------------------------------------------------------------
|   NAME      |      		Description             |     Author   
|-------------+-----------------------------------------+---------------------------
| adpcm       | Adaptive Differential Pulse-Code        | Siyuan Xu,FFmpeg
|	      |	Modulation (encoder part only)         	| PolyU DARClab 
|-------------+-----------------------------------------+--------------------------
| aes         | Advanced Encryption standared (AES)     | pjc.co.jp 
| 	      | 128-bits (cipher and inv cipher)        | Siyuan Xu,Shuangnan Liu, PolyU DARClab 
|-------------+-----------------------------------------+--------------------------
| fir         | 10-Tap FIR filter                       | Siyuan Xu,PolyU DARClab 
|-------------+-----------------------------------------+--------------------------
| decimation  | 5 Stages decimation filter              | Siyuan Xu,PolyU DARClab
|-------------+-----------------------------------------+--------------------------
|interpolation| 4 Stages interpolation filter           | Siyuan Xu,PolyU DARClab
|-------------+-----------------------------------------+--------------------------
| kasumi      | Kasumi encryption algorithm             | Siyuan Xu,ETSI/SAGE
|             |						| PolyU DARClab
|-------------+-----------------------------------------+--------------------------
| md5c        | Message Digest Algorithm                | Siyuan Xu,RSA Data Security, Inc
|	      |						| PolyU DARClab
|-------------+-----------------------------------------+--------------------------
| qsort       | Quick sort                              | Siyuan Xu,Darel Rex Finley 
|	      | 					| PolyU DARClab
|-------------+-----------------------------------------+--------------------------
| snow3G      | snow 3G encryption algorithm            | Siyuan Xu,ETSI/SAGE
|	      |						| PolyU DARClab
|-------------+-----------------------------------------+--------------------------
| sobel       | Sobel filter                            | Siyuan Xu,Anushree Mahapatra
|             |                                         | PolyU DARClab
|-------------+-----------------------------------------+------------------------


Folder contains the following files:
=========================================================================================================

1. soc_system.rbf --Copy to the MicroSD Card and will automatically configure the FPGA when booting
                    the DE1-SoC FPGA Board

=========================================================================================================

2.test_vector (Directory)

%% Copy to the Linux folder, go to that directory and type "./AS2CBench -qws" will launch the GUI of AS2CBench

Stimuli files (.txt)
-------------------
<name>.txt       :  File with iput stimuli (could be more than one).
<name>_golden.txt :  File with golden output with which the simulation results will be compared.

=========================================================================================================

3.Project (Directory)

3.1 Quartus II Project Template fiels
------------------------------------
Includes all the Verilog-HDL files.The user can add their own UUT file if they want more.

And can regenerate the soc_system.rbf by using the Quartus II software.

3.2 QT creator File
------------------------------------
Includes all the files for building the GUI of AS2CBench .

benchmark.cpp /.h : Main description of the benchmark.
define.h  : Includes define statments and stimuli filenames.



=========================================================================================================
Extraction instruction (Linux):
%tar -zxvf AS2Cbench_<ver>.tar.gz


							[END]





