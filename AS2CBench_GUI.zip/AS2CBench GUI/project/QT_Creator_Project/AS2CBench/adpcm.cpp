#include "define.h"

   struct adpcm_width_data {
       unsigned int in_data;    // Current input data
       unsigned int pre_data;    // Previous input data
       unsigned int diff_data;
       unsigned int enc_data;
    } adpcm_width;

    unsigned int step_table[89] = {
      7, 8, 9, 10, 11, 12, 13, 14, 16, 17,
      19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
      50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
      130, 143, 157, 173, 190, 209, 230, 253, 279, 307,
      337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
      876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066,
      2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358,
      5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899,
      15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767
    };

    unsigned int adpcm_index;
    unsigned int index_delta;
    unsigned int divider;
    unsigned int remainder0;
    unsigned int remainder01;
    bool neg_flag;
    unsigned int dec_tmp;
    unsigned int temp = 0;
    unsigned int diff;

  //For data feeding
  FILE * in_adpcm_file, *adpcm_out_file_golden, *adpcm_out_file, *adpcm_diff_file;



unsigned int MainWindow::adpcm_get_index_delta( unsigned int enc )
{
   if( enc>=0 && enc<=3 ) return 1;
   else if( enc==4 ) return 2;
   else if( enc==5 ) return 4;
   else if( enc==6 ) return 6;
   else              return 8;
}


unsigned int MainWindow::adpcm_div_mod(unsigned int numerator, unsigned int denominator )
{
   unsigned int quotient=0;
   unsigned int remainder0;
   unsigned int temp;
   unsigned int d=0;
   int i;

   for ( i=17; i>=0; i-- ) {

    // d = (d<<1) + numerator[i];
    d = (d<<1) +((numerator & (1 << i))>>i);

     if( d >= denominator ){
       d -= denominator;
       quotient += (0x1<<i);
     }
   }
   remainder0 = d;
   temp = (quotient<<17) + remainder0;
   return temp;
}


//---------------------------
// Compare results function
//---------------------------
void MainWindow::adpcm_compare_results(bool hwsw){

  unsigned int out_adpcm, out_golden;
  int  line=1, errors=0;
 char szText[64];



  // Open results file
  if(hwsw) adpcm_out_file = fopen (ADPCM_OUTFILENAMEHWSW, "rt");
  else  adpcm_out_file = fopen (ADPCM_OUTFILENAMESW, "rt");


  if(!adpcm_out_file){
    exit(EXIT_FAILURE);
  }

  //
  // Load the golden pattern
  //

  if(hwsw) adpcm_out_file_golden = fopen (ADPCM_OUTFILENAME_GOLDENHWSW, "rt");
  else adpcm_out_file_golden = fopen (ADPCM_OUTFILENAME_GOLDENSW, "rt");

  if(!adpcm_out_file_golden){
    exit(EXIT_FAILURE);
  }


    //
    // Dump the comparison result
    //
    if(hwsw) adpcm_diff_file = fopen (ADPCM_DIFFFILENAMEHWSW, "w");
    else adpcm_diff_file = fopen (ADPCM_DIFFFILENAMESW, "w");


    if(!adpcm_diff_file){
       }
    fscanf(adpcm_out_file_golden, "%u", &out_golden) ;
    fscanf(adpcm_out_file,"%u", &out_adpcm) ;


    while(fscanf(adpcm_out_file_golden, "%u", &out_golden) != EOF){

      if(fscanf(adpcm_out_file,"%u", &out_adpcm) == EOF)
    break;



      if(out_adpcm != out_golden ){
    fprintf(adpcm_diff_file,"\nOutput missmatch[line:%d] Golden: %u -- Output: %u",line, out_golden, out_adpcm);

    if(hwsw) sprintf(szText,"adpcm(ARM+FPGA)::Output missmatch[line:%d] Golden: %u -- Output: %u",line, out_golden, out_adpcm);
    else   sprintf(szText,"adpcm(ARM)::Output missmatch[line:%d] Golden: %u -- Output: %u",line, out_golden, out_adpcm);
    ui->textBrowser->append(szText);


    errors++;
      }

      line ++;

    }

    if(errors == 0){
       if(hwsw)  ui->textBrowser->append("Finished adpcm ARM+FPGA simulation SUCCESSFULLY !! " );
       else  ui->textBrowser->append("Finished adpcm Pure ARM simulation SUCCESSFULLY !! " );
    }

    else{

       if(hwsw) sprintf(szText, "adpcm(ARM+FPGA)::MISMATCH :: %u out of %u ",errors,line);
       else  sprintf(szText, "adpcm(ARM)::MISMATCH :: %u out of %u ",errors,line);
        ui->textBrowser->append(szText);



    }


    fclose(adpcm_out_file);
    fclose(adpcm_diff_file);
    fclose(adpcm_out_file_golden);



}



//-------------------
// Send data thread
//------------------
void MainWindow::adpcm_send(bool hwsw){


  // Variables declaration
  unsigned int  indata;
  int read;
  int count=0;
  //char szText[64];

// Variables declaration
  unsigned int outdata;

  if( (index.compare("Default File")==0 )| (index.compare("Select File...")==0) ) {//open file
   ui->progressBar->setRange(0,100);

  if(hwsw) adpcm_out_file = fopen (ADPCM_OUTFILENAMEHWSW, "wt");
  else adpcm_out_file = fopen (ADPCM_OUTFILENAMESW, "wt");

  if(!adpcm_out_file){
    printf( "Can not open out file \n " );
    exit (-1);
  }


  //Reset routine

 // in_adpcm_file = fopen(ADPCM_INFILENAME, "rt");
  if(index.compare("Default File")==0 ){   in_adpcm_file = fopen(ADPCM_INFILENAME, "rt");}
  else if(index.compare("Select File...")==0){in_adpcm_file  = fopen(ui->textEdit_adpcm->toPlainText().toLatin1().data(), "rt");}


  if(!in_adpcm_file){
   printf( "Can not open in file \n " );
    exit(EXIT_FAILURE);
  }



    while(fscanf(in_adpcm_file,"%u", &indata) != EOF){

        count++;
        ui->progressBar->setValue(count);

    if(hwsw) { alt_write_word(h2p_lw_UUT_addr,indata);

    //printf("indata is %u\n",indata);

        while(1)	{
             read=alt_read_word(h2p_lw_outvalid_addr);

            if(read==1)
            {
             alt_write_word(h2p_lw_outvalid_addr,true);
            outdata = alt_read_word(h2p_lw_UUT_addr);
             fprintf(adpcm_out_file,"%d\n",outdata);
            // printf("output is %d\n",outdata);
             break;

            }

            }
    }
    else {
     adpcm_width.in_data=indata;
     divider = step_table[ adpcm_index ];

      // Encode
      diff = (adpcm_width.in_data - adpcm_width.pre_data) & 0x0000ffff;
  //    if( diff(15)==1 ){

    if( (diff & (1 << 15))== 0x8000 ){
         adpcm_width.diff_data = ((diff^0xffff) + 1);
         neg_flag = true;
      }
      else {
         adpcm_width.diff_data = diff;
         neg_flag = false;
      }

      adpcm_width.diff_data = (adpcm_width.diff_data<<2);
      temp = adpcm_div_mod( adpcm_width.diff_data, divider );

    adpcm_width.enc_data = ( (temp >> 28) );
    remainder0 = temp & 0x00003fff;


      remainder0 *=2;
      if( remainder0 >= divider ) adpcm_width.enc_data += 1;

      // Decode in the case of overflow
      if( adpcm_width.enc_data > 7 ){
         adpcm_width.enc_data = 7;
         dec_tmp = adpcm_width.enc_data * divider;

    remainder01 = dec_tmp & 0x00000003;
         if( remainder01 >= 2 ){
            adpcm_width.pre_data += (dec_tmp >> 2) + 1;
         }
     else {
            adpcm_width.pre_data += (dec_tmp >> 2);
         }
      }
      else {
         adpcm_width.pre_data = adpcm_width.in_data;
      }

      // Output encoded data
      if( neg_flag == true ){

    outdata = (adpcm_width.enc_data + 0x8);
    fprintf(adpcm_out_file,"%u\n",outdata);
      }
      else {

    outdata = (adpcm_width.enc_data );
    fprintf(adpcm_out_file,"%u\n",outdata);
      }

      // Next step preparation
      index_delta = adpcm_get_index_delta( adpcm_width.enc_data );

      if( adpcm_index==0 && index_delta==1 ){
         adpcm_index = 0;
      }
      else if( index_delta==1 ) {
         adpcm_index -= 1;
      }
      else {
         adpcm_index += index_delta;

      }




    }
  }

    fclose(in_adpcm_file);
    // Close file where outputs are stored
    fclose(adpcm_out_file);
    ui->progressBar->setValue(100);

 //   printf( "Starting comparing results \n " );
 if(index.compare("Default File")==0 ){
    if(hwsw)  adpcm_compare_results(true);
    else     adpcm_compare_results(false); }  }


  else if(index.compare("Random")==0) {//open file --- don't need to compare


      ui->progressBar->setRange(0,index_val-1);

           for(unsigned long index_xx=0;index_xx<index_val;index_xx++) {

               ui->progressBar->setValue(index_xx);

                if(hwsw)  alt_write_word(h2p_lw_UUT_addr,rand()%255);
                else  indata = rand()%255;


      if(hwsw) {

      //printf("indata is %u\n",indata);

          while(1)	{
               read=alt_read_word(h2p_lw_outvalid_addr);

              if(read==1)
              {
               alt_write_word(h2p_lw_outvalid_addr,true);
              outdata = alt_read_word(h2p_lw_UUT_addr);
               //fprintf(adpcm_out_file,"%d\n",outdata);
              // printf("output is %d\n",outdata);
               break;

              }

              }
      }
      else {
       adpcm_width.in_data=indata;
       divider = step_table[ adpcm_index ];

        // Encode
        diff = (adpcm_width.in_data - adpcm_width.pre_data) & 0x0000ffff;
    //    if( diff(15)==1 ){

      if( (diff & (1 << 15))== 0x8000 ){
           adpcm_width.diff_data = ((diff^0xffff) + 1);
           neg_flag = true;
        }
        else {
           adpcm_width.diff_data = diff;
           neg_flag = false;
        }

        adpcm_width.diff_data = (adpcm_width.diff_data<<2);
        temp = adpcm_div_mod( adpcm_width.diff_data, divider );

      adpcm_width.enc_data = ( (temp >> 28) );
      remainder0 = temp & 0x00003fff;


        remainder0 *=2;
        if( remainder0 >= divider ) adpcm_width.enc_data += 1;

        // Decode in the case of overflow
        if( adpcm_width.enc_data > 7 ){
           adpcm_width.enc_data = 7;
           dec_tmp = adpcm_width.enc_data * divider;

      remainder01 = dec_tmp & 0x00000003;
           if( remainder01 >= 2 ){
              adpcm_width.pre_data += (dec_tmp >> 2) + 1;
           }
       else {
              adpcm_width.pre_data += (dec_tmp >> 2);
           }
        }
        else {
           adpcm_width.pre_data = adpcm_width.in_data;
        }

        // Output encoded data
        if( neg_flag == true ){

      outdata = (adpcm_width.enc_data + 0x8);
     // fprintf(adpcm_out_file,"%u\n",outdata);
        }
        else {

      outdata = (adpcm_width.enc_data );
    //  fprintf(adpcm_out_file,"%u\n",outdata);
        }

        // Next step preparation
        index_delta = adpcm_get_index_delta( adpcm_width.enc_data );

        if( adpcm_index==0 && index_delta==1 ){
           adpcm_index = 0;
        }
        else if( index_delta==1 ) {
           adpcm_index -= 1;
        }
        else {
           adpcm_index += index_delta;

        }




      }


  }

  }



}


//--------------------------
// Main function
//--------------------------
void  MainWindow::adpcm_main(bool hwsw,bool single_double) //0:ARM 1:ARM+FPGA
{


    void *virtual_base;
    int fd;
    QPixmap pixmap;
    GET_TIME_INIT(3);
    char szText[64];
    double compare_t[2];
    double compare_bool;

        if(hwsw)  { //ARM+FPGA
    // map the address space for the LED registers into user space so we can interact with them.
    // we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
    if( ( fd = ::open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );

    }
    virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        ::close( fd );

    }
    h2p_lw_UUT_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_3_BASE) & ( unsigned long)( HW_REGS_MASK ) );
    h2p_lw_outvalid_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + VALID_OUT_3_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
    if(single_double){
        ui->textBrowser->append("Start the  adpcm simulation...");
          fprintf(as2cbench,"Start the  adpcm simulation...\n");

        GET_TIME_VAL(0);
        adpcm_send(false);  //ARM
        GET_TIME_VAL(1);
        adpcm_send(true);  //ARM+FPGA
        GET_TIME_VAL(2);

        compare_t[0]=(TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0;
        compare_t[1]=(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0;

        compare_bool=(compare_t[0]-compare_t[1])/compare_t[0];
        compare_bool=(compare_bool*100); //==> 100%
        ui->textBrowser->append("End of the  adpcm Filter simulation..");
        ui->textBrowser->append("  ");
        ui->textBrowser->append("   adpcm Simulation Results: ");
        ui->textBrowser->append(" -------------------------------------------- ");
        ui->textBrowser->append("   Pure ARM     ||     ARM+FPGA  : ");
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "adpcm Accelerated %0.2lf%%",compare_bool);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" ----------------------------------------------------------- ");

        fprintf(as2cbench,"End of the adpcm simulation..\n");
        fprintf(as2cbench,"  \n");
        fprintf(as2cbench,"   adpcm Simulation Results: \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        fprintf(as2cbench,"   Pure ARM     ||     ARM+FPGA  : \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "Accelerated %0.2lf%%\n",compare_bool);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," ----------------------------------------------------------- \n");
    }


    else{
        ui->textBrowser->append("Start the adpcm ARM+FPGA simulation...");
          fprintf(as2cbench,"Start the  adpcm ARM+FPGA simulation...\n");
    GET_TIME_VAL(0);
    adpcm_send(true);  //ARM+FPGA
    GET_TIME_VAL(1);
    ui->textBrowser->append("End of the  adpcm ARM+FPGA simulation..");
     fprintf(as2cbench,"End of the  adpcm ARM+FPGA simulation..\n");

    sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
    ui->textBrowser->append(szText);
    fprintf(as2cbench,szText);

    }
    if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
        printf( "ERROR: munmap() failed...\n" );
        ::close( fd );

    }

    ::close( fd );  }


        else {
            ui->textBrowser->append("Start the  adpcm ARM simulation...");
              fprintf(as2cbench,"Start the adpcm ARM simulation...\n");
            GET_TIME_VAL(0);
            adpcm_send(false);  //ARM
            GET_TIME_VAL(1);
            ui->textBrowser->append("End of the  adpcm ARM simulation..");
             fprintf(as2cbench,"End of the  adpcm ARM simulation..\n");

            sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
            ui->textBrowser->append(szText);
             fprintf(as2cbench,szText);

    }




}
