#include "define.h"

  //For data feeding
  FILE * aes_de_in_file, *aes_de_in_file_key,  *aes_de_out_golden_file, *aes_de_out_file;
  FILE  *aes_de_out_aes_cipher_file, *aes_de_diff_file;

  unsigned int  input_key[AES_DE_SIZE];
  int mode=1;

  //int w[60];
  int aes_de_data[NB];
  //unsigned int init[AES_DE_SIZE];
 // unsigned int key[32];





  int  MainWindow::aes_de_Computing(int *data, int *sboxs)
  {
    int i;

       aes_de_AddRoundKey(data,0);

   // Cyber unroll_times = 0
    for(i=1;i<nr;i++)
      {
        aes_de_SubBytes(data, sboxs);
        aes_de_ShiftRows(data);
        aes_de_MixColumns(data);
           aes_de_AddRoundKey(data,i);
      }

    aes_de_SubBytes(data, sboxs);
    aes_de_ShiftRows(data);
       aes_de_AddRoundKey(data,i);
    return(i);
  }

  /************************************************************/


  void MainWindow::aes_de_SubBytes(int *data, const int sboxs[256])
  {
    int i,j;
    unsigned char cb[4];
    int wrk;


    for(i=0;i<NBb;i+=4)
      {
        wrk = data[i/4];
        for(j=0;j<4;j++)
      {
        cb[j] = sboxs[(wrk >> ((3-j)*8)) & 0xff];


      }

        for(j=0;j<4;j++) {
      wrk = (wrk << 8) | cb[j];

        }

        data[i/4] = wrk;
      }
  }

  /************************************************************/

  void  MainWindow::aes_de_ShiftRows(int *data)
  {
    int i, j;
    int cb[NB];

    if (mode == 0) {
    for (i = 0; i < NB; i ++) {
      cb[i] = 0;
      for (j = 3; j >= 0; j --) {
        cb[i] = (cb[i] << 8) | ((data[(i+j)&3] >> (j*8)) & 0xff);
      }

    }
    for (i = 0; i < NB; i ++) {
      data[i] = cb[i];
    }
    }
    else {
        for (i = 3; i >= 0; i --)
      {
          cb[i] = 0;
          for (j = 0; j < 4; j ++)
          {
              cb[i] = (cb[i] << 8) | ((data[(i+j)&3] >> ((3-j)*8)) & 0xff);
          }

      }

      for (i = 0; i < NB; i ++)
      {
          int j=(i+1)%4;
          data[i] = cb[j];
      }
    }
  }

  /************************************************************/
  int MainWindow::aes_de_mul(int dt,int n)
  {
    int i,x=0;
    for(i=8;i>0;i>>=1)
      {
        x <<= 1;
        if(x&0x100)
      x = (x ^ 0x1b) & 0xff;
        if((n & i))
      x ^= dt;
      }
    return(x);
  }

  /************************************************************/

  int MainWindow::aes_de_dataget(int *data,int n) {
    int ret;

    ret = (data[(n>>2)] >> ((n & 0x3) * 8)) & 0xff;
    return (ret);
  }


  /************************************************************/

  void  MainWindow::aes_de_MixColumns(int *data)
  {
    int i,i4,x;
    int a,b,c,d;
    if (mode == 0) {
      a = 2;
      b = 3;
      c = 1;
      d = 1;
    }
    else {
      a = 0x0e;
      b = 0x0b;
      c = 0x0d;
      d = 0x09;
    }
   // Cyber unroll_times =0
    for(i=0;i<NB;i++)
      {
        i4 = i*4;
        x  =  aes_de_mul(aes_de_dataget(data,i4+0),a) ^
              aes_de_mul(aes_de_dataget(data,i4+1),b) ^
              aes_de_mul(aes_de_dataget(data,i4+2),c) ^
              aes_de_mul(aes_de_dataget(data,i4+3),d);
        x |= (aes_de_mul(aes_de_dataget(data,i4+1),a) ^
              aes_de_mul(aes_de_dataget(data,i4+2),b) ^
              aes_de_mul(aes_de_dataget(data,i4+3),c) ^
              aes_de_mul(aes_de_dataget(data,i4+0),d)) << 8;
        x |= (aes_de_mul(aes_de_dataget(data,i4+2),a) ^
              aes_de_mul(aes_de_dataget(data,i4+3),b) ^
              aes_de_mul(aes_de_dataget(data,i4+0),c) ^
              aes_de_mul(aes_de_dataget(data,i4+1),d)) << 16;
        x |= (aes_de_mul(aes_de_dataget(data,i4+3),a) ^
              aes_de_mul(aes_de_dataget(data,i4+0),b) ^
              aes_de_mul(aes_de_dataget(data,i4+1),c) ^
              aes_de_mul(aes_de_dataget(data,i4+2),d)) << 24;
        data[i] = x;
      }
  }

  /************************************************************/

  void     MainWindow::aes_de_AddRoundKey(int *data, int n)
  {
    int i,m;
    if (mode == 0)
      m = n;
    else
      m = nr - n;

    for(i=0;i<NB/2;i++)
      {
      data[i*2] ^= w[i*2  +NB*m];
      data[i*2+1] ^= w[i*2+1+NB*m];

      }
  }

  /************************************************************/

  int MainWindow::aes_de_SubWord(int word, const int Sbox[256])
  {
    int inw=word;
    int i;


    for (i = 3; i >= 0; i--) {
      inw = (inw<<8) | Sbox[(word>>(8*i)) & 0xff];
    }

    return(inw);
  }

  /************************************************************/
  int  MainWindow::aes_de_RotWord(int word)
  {
    int inw=word,inw2=0;

    inw2 = ((inw & 0xff) << 24) | ((inw >> 8) & 0x00ffffff);
    return(inw2);
  }


  /************************************************************/
  void MainWindow::aes_de_KeyExpansion(unsigned int *key, int const Sbox[256])
  {


    int Rcon[10]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36};
    int i,temp;
    int j;

    for (i = 0; i < nk*4/4; i ++) {
      temp = 0;
      for (j = 3; j >= 0; j --) {
        temp = (temp << 8) | key[i*4+j];
      }
      w[i] = temp;
    }
  // Cyber unroll_times =0
    for(i=nk;i<NB*(nr+1);i++)
      {
        temp = w[i-1];
        if((i%nk) == 0)
      temp = aes_de_SubWord(aes_de_RotWord(temp), Sbox) ^ Rcon[(i/nk)-1];
        w[i] = w[i-nk] ^ temp;
      }

    if (mode == 1) {

      int cw[4];
      int m,n;
      for (m = 1; m < nr; m++) {
          n = 4 * m;
          cw[0] = w[n];
          cw[1] = w[n + 1];
          cw[2] = w[n + 2];
          cw[3] = w[n + 3];
          aes_de_MixColumns(cw);
          w[n]   = cw[0];
          w[n+1] = cw[1];
          w[n+2] = cw[2];
          w[n+3] = cw[3];
      }
    }
  }
/*
** Compare results function
*/
void MainWindow::aes_de_compare_results(bool hwsw){

  unsigned int outaes, out_golden, line=1, element=1, errors=0,num=1;
 char szText[64];
  // Close file where outputs are stored
  //fclose(aes_de_out_file);

  //  out_filter_file_read.open(OUTFILENAME);

  if(hwsw)
  aes_de_out_file = fopen (AES_DE_OUTFILENAMEHWSW, "rt");
  else
  aes_de_out_file = fopen (AES_DE_OUTFILENAMESW, "rt");

  if(!aes_de_out_file){

    printf("Could not open  AES_DE_OUTFILENAME \n" );
    exit(-1);
  }

    //
    //Load the golden pattern
    //

  if(hwsw)
  aes_de_out_golden_file = fopen (AES_DE_OUTFILENAME_GOLDENHWSW, "rt");
  else
  aes_de_out_golden_file = fopen (AES_DE_OUTFILENAME_GOLDENSW, "rt");

  if(!aes_de_out_golden_file){

    printf("Could not open  AES_DE_OUTFILENAME_GOLDEN \n" );
   exit(-1);
  }

    //
    //Dump the comparison result
    //
  if(hwsw)
    aes_de_diff_file = fopen (AES_DE_DIFFFILENAMEHWSW, "w");
  else
    aes_de_diff_file = fopen (AES_DE_DIFFFILENAMESW, "w");

    if(!aes_de_diff_file){
     printf(" Could not open  AES_DE_DIFFFILENAME \n" );

       }

    while(fscanf(aes_de_out_golden_file, "%x", &out_golden) != EOF){
      fscanf(aes_de_out_file,"%x", &outaes);

      if(outaes != out_golden){
    fprintf(aes_de_diff_file,"\nOutput missmatch[line:%d][%d] Golden: %u -- Output: %u",line,element, out_golden, outaes);

    if(hwsw) sprintf(szText,"aes_decipher(ARM+FPGA)::Output missmatch[line:%d][%d] Golden: %u -- Output: %u",line,element, out_golden, outaes);
    else sprintf(szText,"aes_decipher(ARM)::Output missmatch[line:%d][%d] Golden: %u -- Output: %u",line,element, out_golden, outaes);
    ui->textBrowser->append(szText);
      errors++;
      }

      if(element == AES_DE_SIZE){
    element =0;
    line ++;
      }
      element ++;
      num++;
   }

    if(errors == 0){
       if(hwsw)  ui->textBrowser->append("Finished AES Decipher ARM+FPGA AES Decipher Simulation SUCCESSFULLY !! " );
       else  ui->textBrowser->append("Finished AES Decipher Pure ARM AES Decipher Simulation SUCCESSFULLY !! " );
    }

    else{

        if(hwsw) sprintf(szText, "aes_decipher(ARM+FPGA)::MISMATCH :: %u out of %u ",errors,num);
        else sprintf(szText, "aes_decipher(ARM)::MISMATCH :: %u out of %u ",errors,num);
        ui->textBrowser->append(szText);



    }

    fclose(aes_de_out_file);
    fclose(aes_de_diff_file);
    fclose(aes_de_out_golden_file);


}



/*
** Send data thread
*/
void MainWindow::aes_de_send(bool hwsw){

  // Variables declaration
  int i=0,read,j=0,h=0;
  unsigned int  in_read[AES_DE_SIZE], in_read_key[AES_DE_SIZE];
  // Variables declaration
  unsigned int out_write[AES_DE_SIZE];
  char szText[64];


  if((index.compare("Default File")==0)  | (index.compare("Select File...")==0) ) {//open file
  ui->progressBar->setRange(0,AES_DE_SIZE);

  if(hwsw)
    aes_de_out_file = fopen (AES_DE_OUTFILENAMEHWSW, "wt");
  else
    aes_de_out_file = fopen (AES_DE_OUTFILENAMESW, "wt");


  if(!aes_de_out_file){

    printf( "Could not open  AES_DE_OUTFILENAME \n" );
    exit(-1);
  }

  //Reset routine

  if(index.compare("Default File")==0 ){   aes_de_in_file = fopen(AES_DE_INFILENAME, "rt");}
  else if(index.compare("Select File...")==0){aes_de_in_file = fopen(ui->textEdit_aesde->toPlainText().toLatin1().data(), "rt");}



  if(!aes_de_in_file){
   printf("Could not open  INFILENAME \n" );
    exit (-1);
  }

  aes_de_in_file_key = fopen(AES_DE_INFILENAME_KEY, "rt");

  if(!aes_de_in_file_key){
    printf( "Could not open AES_INFILENAME_KEY \n" );
    exit (-1);
  }


  for(i=0; i < AES_DE_SIZE; i ++){
    fscanf(aes_de_in_file_key, "%x", &in_read_key[i]);
    if(hwsw) alt_write_word(h2p_lw_UUT_addr, in_read_key[i]);
    else key[i] = in_read_key[i];

    sprintf(szText, "%x \r", in_read_key[i]);
    //ui->textBrowserkey->append(szText);
  }

  h=0;



    /**** Read in data to be encrypted  ****/

    while(fscanf(aes_de_in_file,"%x", &in_read[h]) != EOF){

    if(hwsw) alt_write_word(h2p_lw_UUT_addr, in_read[h]);
     else init[h]=in_read[h];

     sprintf(szText, "%x \r", in_read[h]);
     //ui->textBrowserin->append(szText);

    //printf("in_read is %x\n",in_read);
        h++;
     ui->progressBar->setValue(h);

    if(h==AES_DE_SIZE){

      h=0;

      if(hwsw) {

          while(1)	{
                       read=alt_read_word(h2p_lw_outvalid_addr);

                      if(read)
                      {
                      for(i=0; i< AES_DE_SIZE; i++){
                       alt_write_word(h2p_lw_outvalid_addr,true);
                       out_write[i]= alt_read_word(h2p_lw_UUT_addr);
                       fprintf(aes_de_out_file,"%x ",(unsigned int)out_write[i]);
                       sprintf(szText, "%x \r", (unsigned char)out_write[i]);
                       //ui->textBrowserout->append(szText);
                      }
                      fprintf(aes_de_out_file,"\n");
                       break;

                      }

                      }



      }

 else{
    /**** Key expansion****/
    aes_de_KeyExpansion(key, Sbox);

    /**** Data conversion  *****/
    for (i = 0; i < NBb/4; i ++) {
      wrk = 0;
      for (j = 3; j >= 0; j --) {
    wrk = (wrk << 8) | init[i*4+j];
      }
      aes_de_data[i] = wrk;
    }

    /**** Encrypt data   *****/

    aes_de_Computing(aes_de_data, invSbox);


    /*** Output data ****/
  for (i = 0; i < NB; i ++) {
    for (j = 0; j < NB; j++) {
   out_write[(i*NB)+j]= aes_de_data[i] >> (j * 8);
   fprintf(aes_de_out_file,"%x ",(unsigned char)out_write[(i*NB)+j]);
   sprintf(szText, "%x \r\n", (unsigned char)out_write[(i*NB)+j]);
   //ui->textBrowserout->append(szText);
    }
  }
fprintf(aes_de_out_file,"\n");    }





        }




                            }


  ui->progressBar->setValue(AES_SIZE);
    fclose(aes_de_in_file);
    fclose(aes_de_in_file_key);
    fclose(aes_de_out_file);
     if(index.compare("Default File")==0 ){
  if(hwsw)
   aes_de_compare_results(true);
  else
        aes_de_compare_results(false);}


  }

  else if(index.compare("Random")==0) {//open file --- don't need to compare

          ui->progressBar->setRange(0,index_val-1);

      for(int index_yy=0;index_yy<AES_DE_SIZE;index_yy++){
       if(hwsw)  alt_write_word(h2p_lw_UUT_addr,rand()%255);
       else key[index_yy] = rand()%255;
   }



           for(unsigned long index_xx=0;index_xx<index_val;index_xx++) {

              ui->progressBar->setValue(index_xx);

      if(hwsw) {

          for(int index_yy=0;index_yy<AES_SIZE;index_yy++){
           alt_write_word(h2p_lw_UUT_addr,rand()%255);
       }

          while(1)	{
                       read=alt_read_word(h2p_lw_outvalid_addr);

                      if(read)
                      {
                      for(i=0; i< AES_DE_SIZE; i++){
                       alt_write_word(h2p_lw_outvalid_addr,true);
                       out_write[i]= alt_read_word(h2p_lw_UUT_addr);

                      }

                       break;

                      }

                      }



      }

 else{

          for(int index_yy=0;index_yy<AES_DE_SIZE;index_yy++){
          init[index_yy]= rand()%255; }
    /**** Key expansion****/
    aes_de_KeyExpansion(key, Sbox);

    /**** Data conversion  *****/
    for (i = 0; i < NBb/4; i ++) {
      wrk = 0;
      for (j = 3; j >= 0; j --) {
    wrk = (wrk << 8) | init[i*4+j];
      }
      aes_de_data[i] = wrk;
    }

    /**** Encrypt data   *****/

    aes_de_Computing(aes_de_data, invSbox);


    /*** Output data ****/
  for (i = 0; i < NB; i ++) {
    for (j = 0; j < NB; j++) {
   out_write[(i*NB)+j]= aes_de_data[i] >> (j * 8);

    }
  }
  }



  }


  }



}




//--------------------------
// Main function
//--------------------------


void  MainWindow::aes_de_main(bool hwsw,bool single_double) //0:ARM 1:ARM+FPGA
{


    void *virtual_base;
    int fd;
    QPixmap pixmap;
    GET_TIME_INIT(3);
    char szText[64];
    double compare_t[2];
   double compare_bool;

        if(hwsw)  { //ARM+FPGA
    // map the address space for the LED registers into user space so we can interact with them.
    // we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
    if( ( fd = ::open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );

    }
    virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        ::close( fd );

    }
    h2p_lw_UUT_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_6_BASE) & ( unsigned long)( HW_REGS_MASK ) );
    h2p_lw_outvalid_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + VALID_OUT_6_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
    if(single_double){
        ui->textBrowser->append("Start the  aes_decipher AES Decipher Simulation...");
        fprintf(as2cbench,"Start the  aes_decipher AES Decipher Simulation...\n");

        GET_TIME_VAL(0);
        aes_de_send(false);  //ARM
        GET_TIME_VAL(1);
        aes_de_send(true);  //ARM+FPGA
        GET_TIME_VAL(2);

        compare_t[0]=(TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0;
        compare_t[1]=(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0;

        compare_bool=(compare_t[0]-compare_t[1])/compare_t[0];
        compare_bool=(compare_bool*100); //==> 100%
        ui->textBrowser->append("End of the  aes_decipher AES Decipher Simulation..");
        ui->textBrowser->append(" ");
        ui->textBrowser->append("   AES Decipher AES Decipher Simulation Results: ");
        ui->textBrowser->append(" -------------------------------------------- ");
        ui->textBrowser->append("   Pure ARM     ||     ARM+FPGA  : ");
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "AES Decipher Accelerated %0.2lf%%",compare_bool);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" ----------------------------------------------------------- ");

        fprintf(as2cbench,"End of the  aes Decipher AES Decipher Simulation..\n");
        fprintf(as2cbench,"  \n");
        fprintf(as2cbench,"   AES Decipher AES Decipher Simulation Results: \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        fprintf(as2cbench,"   Pure ARM     ||     ARM+FPGA  : \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "Accelerated %0.2lf%%\n",compare_bool);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," ----------------------------------------------------------- \n");
    }


    else{
        ui->textBrowser->append("Start the  aes_decipher ARM+FPGA AES Decipher Simulation...");
        fprintf(as2cbench,"Start the  aes_decipher ARM+FPGA AES Decipher Simulation...\n");
    GET_TIME_VAL(0);
    aes_de_send(true);  //ARM+FPGA
    GET_TIME_VAL(1);
      ui->textBrowser->append("End of the  aes_de ARM+FPGA AES Decipher Simulation..");
            fprintf(as2cbench,"End of the  aes Decipher ARM+FPGA AES Decipher Simulation..\n");

    sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
    ui->textBrowser->append(szText);
    fprintf(as2cbench,szText);
    }
    if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
        printf( "ERROR: munmap() failed...\n" );
        ::close( fd );

    }

    ::close( fd );  }


        else {
            ui->textBrowser->append("Start the  aes_decipher ARM AES Decipher Simulation...");
            fprintf(as2cbench,"Start the  aes_decipher ARM AES Decipher Simulation...\n");
            GET_TIME_VAL(0);
            aes_de_send(false);  //ARM
            GET_TIME_VAL(1);
            ui->textBrowser->append("End of the  aes_decipher ARM AES Decipher Simulation..");
                  fprintf(as2cbench,"End of the  aes Decipher ARM AES Decipher Simulation..\n");
            sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
            ui->textBrowser->append(szText);
         fprintf(as2cbench,szText);

    }




}

