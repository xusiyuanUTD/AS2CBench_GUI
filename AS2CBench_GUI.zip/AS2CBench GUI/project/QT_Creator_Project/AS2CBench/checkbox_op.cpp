#include "mainwindow.h"
#include "ui_mainwindow.h"
//#include "QCheckBox"

#include <QtGui>
#include <QPainter>

#include <QLabel>
#include <QLineEdit>
#include <QProgressBar>
#include <QComboBox>
#include <QPushButton>
#include <QGridLayout>
#include <QProgressDialog>
#include <QFont>
#include "timer.h"

void MainWindow::on_checkBox_sobel_toggled(bool checked)
{
   bool x[12];
   QCheckBox *szCheck[] = {
       ui->checkBox_sobel,
       ui->checkBox_fir,
       ui->checkBox_qsort,
       ui->checkBox_aes,
       ui->checkBox_aesde,
       ui->checkBox_kasumi,
       ui->checkBox_md5c,
       ui->checkBox_snow3g,
       ui->checkBox_adpcm,
       ui->checkBox_interp,
   };


   for(int i=0;i<10;i++){

      x[i]=false;
      x[i]=szCheck[i]->isChecked();
   }



       ui->textBrowser_info->clear();


           if(x[0]) { sobel_func  }
           if(x[1]) { fir_func    }
           if(x[2]) { qsort_func  }
           if(x[3]) { aes_func    }
           if(x[4]) { aesde_func  }
           if(x[5]) { kasumi_func }
           if(x[6]) { md5c_func   }
           if(x[7]) { snow3g_func }
           if(x[8]) { adpcm_func   }
           if(x[9]) { interp_func }

           if(checked) {}
           else {ui->checkBox_all->setChecked(false);}



}

void MainWindow::on_checkBox_fir_toggled(bool checked)
{
    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,

    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }

        ui->textBrowser_info->clear();

        if(x[0]) { sobel_func  }
        if(x[1]) { fir_func    }
        if(x[2]) { qsort_func  }
        if(x[3]) { aes_func    }
        if(x[4]) { aesde_func  }
        if(x[5]) { kasumi_func }
        if(x[6]) { md5c_func   }
        if(x[7]) { snow3g_func }
        if(x[8]) { adpcm_func   }
        if(x[9]) { interp_func }

        if(checked) {}
        else {ui->checkBox_all->setChecked(false);}
}

void MainWindow::on_checkBox_qsort_toggled(bool checked)
{
    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,
    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }

        ui->textBrowser_info->clear();

        if(x[0]) { sobel_func  }
        if(x[1]) { fir_func    }
        if(x[2]) { qsort_func  }
        if(x[3]) { aes_func    }
        if(x[4]) { aesde_func  }
        if(x[5]) { kasumi_func }
        if(x[6]) { md5c_func   }
        if(x[7]) { snow3g_func }
        if(x[8]) { adpcm_func   }
        if(x[9]) { interp_func }

        if(checked) {}
        else {ui->checkBox_all->setChecked(false);}
}

void MainWindow::on_checkBox_aes_toggled(bool checked)
{
    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,
    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }

        ui->textBrowser_info->clear();

        if(x[0]) { sobel_func  }
        if(x[1]) { fir_func    }
        if(x[2]) { qsort_func  }
        if(x[3]) { aes_func    }
        if(x[4]) { aesde_func  }
        if(x[5]) { kasumi_func }
        if(x[6]) { md5c_func   }
        if(x[7]) { snow3g_func }
        if(x[8]) { adpcm_func   }
        if(x[9]) { interp_func }

        if(checked) {}
        else {ui->checkBox_all->setChecked(false);}
}

void MainWindow::on_checkBox_aesde_toggled(bool checked)
{
    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,
    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }

        ui->textBrowser_info->clear();

        if(x[0]) { sobel_func  }
        if(x[1]) { fir_func    }
        if(x[2]) { qsort_func  }
        if(x[3]) { aes_func    }
        if(x[4]) { aesde_func  }
        if(x[5]) { kasumi_func }
        if(x[6]) { md5c_func   }
        if(x[7]) { snow3g_func }
        if(x[8]) { adpcm_func   }
        if(x[9]) { interp_func }

        if(checked) {}
        else {ui->checkBox_all->setChecked(false);}
}

void MainWindow::on_checkBox_snow3g_toggled(bool checked)
{
    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,
    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }

        ui->textBrowser_info->clear();

        if(x[0]) { sobel_func  }
        if(x[1]) { fir_func    }
        if(x[2]) { qsort_func  }
        if(x[3]) { aes_func    }
        if(x[4]) { aesde_func  }
        if(x[5]) { kasumi_func }
        if(x[6]) { md5c_func   }
        if(x[7]) { snow3g_func }
        if(x[8]) { adpcm_func   }
        if(x[9]) { interp_func }

        if(checked) {}
        else {ui->checkBox_all->setChecked(false);}
}

void MainWindow::on_checkBox_kasumi_toggled(bool checked)
{
    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,
    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }

        ui->textBrowser_info->clear();

        if(x[0]) { sobel_func  }
        if(x[1]) { fir_func    }
        if(x[2]) { qsort_func  }
        if(x[3]) { aes_func    }
        if(x[4]) { aesde_func  }
        if(x[5]) { kasumi_func }
        if(x[6]) { md5c_func   }
        if(x[7]) { snow3g_func }
        if(x[8]) { adpcm_func   }
        if(x[9]) { interp_func }

        if(checked) {}
        else {ui->checkBox_all->setChecked(false);}
}

void MainWindow::on_checkBox_md5c_toggled(bool checked)
{
    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,
    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }



        ui->textBrowser_info->clear();

        if(x[0]) { sobel_func  }
        if(x[1]) { fir_func    }
        if(x[2]) { qsort_func  }
        if(x[3]) { aes_func    }
        if(x[4]) { aesde_func  }
        if(x[5]) { kasumi_func }
        if(x[6]) { md5c_func   }
        if(x[7]) { snow3g_func }
        if(x[8]) { adpcm_func   }
        if(x[9]) { interp_func }

        if(checked) {}
        else {ui->checkBox_all->setChecked(false);}
}

void MainWindow::on_checkBox_adpcm_toggled(bool checked)
{
    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,
    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }



        ui->textBrowser_info->clear();

        if(x[0]) { sobel_func  }
        if(x[1]) { fir_func    }
        if(x[2]) { qsort_func  }
        if(x[3]) { aes_func    }
        if(x[4]) { aesde_func  }
        if(x[5]) { kasumi_func }
        if(x[6]) { md5c_func   }
        if(x[7]) { snow3g_func }
        if(x[8]) { adpcm_func   }
        if(x[9]) { interp_func }

        if(checked) {}
        else {ui->checkBox_all->setChecked(false);}
}

void MainWindow::on_checkBox_interp_toggled(bool checked)
{
    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,
    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }



        ui->textBrowser_info->clear();

        if(x[0]) { sobel_func  }
        if(x[1]) { fir_func    }
        if(x[2]) { qsort_func  }
        if(x[3]) { aes_func    }
        if(x[4]) { aesde_func  }
        if(x[5]) { kasumi_func }
        if(x[6]) { md5c_func   }
        if(x[7]) { snow3g_func }
        if(x[8]) { adpcm_func   }
        if(x[9]) { interp_func }

        if(checked) {}
        else {ui->checkBox_all->setChecked(false);}
}

/*

int  MainWindow::aes_de_Computing(int *data, int *sboxs)
{
  int i;

  aes_de_AddRoundKey(data,0);

 // Cyber unroll_times = 0
  for(i=1;i<nr;i++)
    {
      aes_de_SubBytes(data, sboxs);
      aes_de_ShiftRows(data);
      aes_de_MixColumns(data);
      aes_de_AddRoundKey(data,i);
    }

  aes_de_SubBytes(data, sboxs);
  aes_de_ShiftRows(data);
  aes_de_AddRoundKey(data,i);
  return(i);
}




void  MainWindow::aes_de_SubBytes(int *data, const int sboxs[256])
{
  int i,j;
  unsigned char cb[4];
  int wrk;


  for(i=0;i<NBb;i+=4)
    {
      wrk = data[i/4];
      for(j=0;j<4;j++)
    {
      cb[j] = sboxs[(wrk >> ((3-j)*8)) & 0xff];


    }

      for(j=0;j<4;j++) {
    wrk = (wrk << 8) | cb[j];

      }

      data[i/4] = wrk;
    }
}



void  MainWindow::aes_de_ShiftRows(int *data)
{
  int i, j;
  int cb[NB];


      for (i = 3; i >= 0; i --)
    {
        cb[i] = 0;
        for (j = 0; j < 4; j ++)
        {
            cb[i] = (cb[i] << 8) | ((data[(i+j)&3] >> ((3-j)*8)) & 0xff);
        }

    }

    for (i = 0; i < NB; i ++)
    {
        int j=(i+1)%4;
        data[i] = cb[j];
    }

}


int MainWindow::aes_de_mul(int dt,int n)
{
  int i,x=0;
  for(i=8;i>0;i>>=1)
    {
      x <<= 1;
      if(x&0x100)
    x = (x ^ 0x1b) & 0xff;
      if((n & i))
    x ^= dt;
    }
  return(x);
}



int MainWindow::aes_de_dataget(int *data,int n) {
  int ret;

  ret = (data[(n>>2)] >> ((n & 0x3) * 8)) & 0xff;
  return (ret);
}




void  MainWindow::aes_de_MixColumns(int *data)
{
  int i,i4,x;
  int a,b,c,d;

    a = 0x0e;
    b = 0x0b;
    c = 0x0d;
    d = 0x09;

 // Cyber unroll_times =0
  for(i=0;i<NB;i++)
    {
      i4 = i*4;
      x  =  aes_de_mul(aes_de_dataget(data,i4+0),a) ^
            aes_de_mul(aes_de_dataget(data,i4+1),b) ^
            aes_de_mul(aes_de_dataget(data,i4+2),c) ^
            aes_de_mul(aes_de_dataget(data,i4+3),d);
      x |= (aes_de_mul(aes_de_dataget(data,i4+1),a) ^
            aes_de_mul(aes_de_dataget(data,i4+2),b) ^
            aes_de_mul(aes_de_dataget(data,i4+3),c) ^
            aes_de_mul(aes_de_dataget(data,i4+0),d)) << 8;
      x |= (aes_de_mul(aes_de_dataget(data,i4+2),a) ^
            aes_de_mul(aes_de_dataget(data,i4+3),b) ^
            aes_de_mul(aes_de_dataget(data,i4+0),c) ^
            aes_de_mul(aes_de_dataget(data,i4+1),d)) << 16;
      x |= (aes_de_mul(aes_de_dataget(data,i4+3),a) ^
            aes_de_mul(aes_de_dataget(data,i4+0),b) ^
            aes_de_mul(aes_de_dataget(data,i4+1),c) ^
            aes_de_mul(aes_de_dataget(data,i4+2),d)) << 24;
      data[i] = x;
    }
}



void  MainWindow::aes_de_AddRoundKey(int *data, int n)
{
  int i,m;

    m = nr - n;

  for(i=0;i<NB/2;i++)
    {
    data[i*2] ^= w[i*2  +NB*m];
    data[i*2+1] ^= w[i*2+1+NB*m];

    }
}



int MainWindow::aes_de_SubWord(int word, const int Sbox[256])
{
  int inw=word;
  int i;


  for (i = 3; i >= 0; i--) {
    inw = (inw<<8) | Sbox[(word>>(8*i)) & 0xff];
  }

  return(inw);
}


int  MainWindow::aes_de_RotWord(int word)
{
  int inw=word,inw2=0;

  inw2 = ((inw & 0xff) << 24) | ((inw >> 8) & 0x00ffffff);
  return(inw2);
}



void MainWindow::aes_de_KeyExpansion(unsigned int *key, int const Sbox[256])
{


  int Rcon[10]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36};
  int i,temp;
  int j;

  for (i = 0; i < nk*4/4; i ++) {
    temp = 0;
    for (j = 3; j >= 0; j --) {
      temp = (temp << 8) | key[i*4+j];
    }
    w[i] = temp;
  }
// Cyber unroll_times =0
  for(i=nk;i<NB*(nr+1);i++)
    {
      temp = w[i-1];
      if((i%nk) == 0)
    temp = aes_de_SubWord(aes_de_RotWord(temp), Sbox) ^ Rcon[(i/nk)-1];
      w[i] = w[i-nk] ^ temp;
    }



    int cw[4];
    int m,n;
    for (m = 1; m < nr; m++) {
        n = 4 * m;
        cw[0] = w[n];
        cw[1] = w[n + 1];
        cw[2] = w[n + 2];
        cw[3] = w[n + 3];
        aes_de_MixColumns(cw);
        w[n]   = cw[0];
        w[n+1] = cw[1];
        w[n+2] = cw[2];
        w[n+3] = cw[3];
    }

}


*/
  /************************************************************/
