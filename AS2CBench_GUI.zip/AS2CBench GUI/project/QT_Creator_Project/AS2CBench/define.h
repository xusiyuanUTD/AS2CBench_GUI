//========================================================================================
// 
// File Name    : define.h
// Description  : Main definition header
// Release Date : 23/07/2013
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Siyuan XU
//
// Revision History
//---------------------------------------------------------------------------------------
// Date        Version   Author         Description
//---------------------------------------------------------------------------------------
//23/07/2013      1.0   PolyU DARC Lab   main definition header            
//=======================================================================================
#ifndef DEFINE_H
#define DEFINE_H

#include "stdio.h"
#include "mainwindow.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "ui_mainwindow.h"
#include <stdio.h>
#include <unistd.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <stdbool.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include <malloc.h>
#include "stdlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include <stdbool.h>
#include <timer.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>
#include <fcntl.h>
#include <qdebug.h>
#include"timer.h"

#define random(x) (rand()%x)


//*************************************************************************************** sobel
   #define BYTES_PER_PIXEL 1
   #define COLS 512 * BYTES_PER_PIXEL
   #define ROWS 512 * BYTES_PER_PIXEL
   #define SIZE ROWS* COLS
   #define IMAGE_IN "lena512.bmp"
   #define IMAGE_OUTSW   "lena512_out_SW.bmp"
   #define IMAGE_OUTHWSW "lena512_out_HWSW.bmp"
   #define IMAGE_GOLDENSW   "lena512_golden_SW.bmp"
   #define IMAGE_GOLDENHWSW "lena512_golden_HWSW.bmp"

#define DIFFFILENAMESW "sobel_diff_SW.txt"
#define DIFFFILENAMEHWSW "sobel_diff_HWSW.txt"

#define SIZE_BUFFER 3



//***************************************************************************************  fir
#define FILTER_TAPS 10

#define FIR_INFILTERFILENAME             "fir_in_data.txt"   // random data
#define FIR_INCOEFFFILENAME              "fir_coeff.txt"

#define FIR_OUTFILENAME_GOLDENHWSW       "fir_output_golden_HWSW.txt"
#define FIR_OUTFILENAME_GOLDENSW         "fir_output_golden_SW.txt"

#define FIR_OUTFILENAMEHWSW              "fir_output_HWSW.txt"
#define FIR_OUTFILENAMESW                "fir_output_SW.txt"

#define FIR_DIFFFILENAMEHWSW             "fir_diff_HWSW.txt"
#define FIR_DIFFFILENAMESW               "fir_diff_SW.txt"


//*************************************************************************************** qsort
#define QSORT_SIZE 10

#define QSORT_INFILENAME                 "qsort_in_data.txt"

#define QSORT_OUTFILENAME_GOLDENHWSW     "qsort_output_golden_HWSW.txt"
#define QSORT_OUTFILENAME_GOLDENSW       "qsort_output_golden_SW.txt"

#define QSORT_OUTFILENAMEHWSW            "qsort_output_HWSW.txt"
#define QSORT_OUTFILENAMESW              "qsort_output_SW.txt"

#define QSORT_DIFFFILENAMEHWSW           "qsort_diff_HWSW.txt"
#define QSORT_DIFFFILENAMESW             "qsort_diff_SW.txt"

//***************************************************************************************aes cipher
#define AES_SIZE 16

#define NB 4
#define NBb 16
#define nk 4
#define nr 10

#define AES_INFILENAME                "aes_cipher_input.txt"
#define AES_INFILENAME_KEY            "aes_cipher_key.txt"

#define AES_OUTFILENAME_GOLDENHWSW        "aes_cipher_output_golden_HWSW.txt"
#define AES_OUTFILENAME_GOLDENSW          "aes_cipher_output_golden_SW.txt"

#define AES_OUTFILENAMEHWSW               "aes_cipher_output_HWSW.txt"
#define AES_OUTFILENAMESW                 "aes_cipher_output_SW.txt"

#define AES_DIFFFILENAMEHWSW              "aes_diff_HWSW.txt"
#define AES_DIFFFILENAMESW                "aes_diff_SW.txt"

//***************************************************************************************aes decipher
#define AES_DE_SIZE 16

#define AES_DE_INFILENAME                "aes_decipher_input.txt"
#define AES_DE_INFILENAME_KEY            "aes_decipher_key.txt"

#define AES_DE_OUTFILENAME_GOLDENHWSW        "aes_decipher_output_golden_HWSW.txt"
#define AES_DE_OUTFILENAME_GOLDENSW          "aes_decipher_output_golden_SW.txt"

#define AES_DE_OUTFILENAMEHWSW               "aes_decipher_output_HWSW.txt"
#define AES_DE_OUTFILENAMESW                 "aes_decipher_output_SW.txt"

#define AES_DE_DIFFFILENAMEHWSW              "aes_de_diff_HWSW.txt"
#define AES_DE_DIFFFILENAMESW                "aes_de_diff_SW.txt"

//***************************************************************************************snow3g
#define SNOW3G_SIZE 4

#define SNOW3G_INFILENAME                   "snow_3G_input.txt"  // random

#define SNOW3G_OUTFILENAME_GOLDENHWSW       "snow_3G_output_golden_HWSW.txt"
#define SNOW3G_OUTFILENAME_GOLDENSW         "snow_3G_output_golden_SW.txt"

#define SNOW3G_OUTFILENAMEHWSW              "snow_3G_output_HWSW.txt"
#define SNOW3G_OUTFILENAMESW                "snow_3G_output_SW.txt"

#define SNOW3G_DIFFFILENAMEHWSW             "snow_3G_diff_HWSW.txt"
#define SNOW3G_DIFFFILENAMESW               "snow_3G_diff_SW.txt"


//***************************************************************************************kasumi
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

#define ROL16(a,b) (u16)((a<<b)|(a>>(16-b)))

typedef struct kasumi_dword{
    u8 b8[4];
}KASUMI_DWORD;

typedef struct kasumi_word {
    u8 b8[2];
} KASUMI_WORD;

#define DEPTH 2
#define WIDTH 4

#define KASUMI_INFILENAME                  "kasumi_indata.txt"  // random data
#define KASUMI_INFILEKEY                   "kasumi_key.txt"    // random data

#define KASUMI_OUTFILENAME_GOLDENHWSW      "kasumi_output_golden_HWSW.txt"
#define KASUMI_OUTFILENAME_GOLDENSW        "kasumi_output_golden_SW.txt"

#define KASUMI_OUTFILENAMEHWSW                 "kasumi_output_HWSW.txt"
#define KASUMI_OUTFILENAMESW                 "kasumi_output_SW.txt"

#define KASUMI_DIFFFILENAMEHWSW                "kasumi_diff_HWSW.txt"
#define KASUMI_DIFFFILENAMESW                "kasumi_diff_SW.txt"

//***************************************************************************************md5c
#define MD5C_INPUT_BUFSIZE   1024
//#define MD5C_INPUT_BUFSIZE_T sc_uint<10>
#define MD5C_INPUT_BUFSIZE_T unsigned int

#define MD5C_INFILENAME                 "md5c_input.txt"      // random

#define MD5C_OUTFILENAME_GOLDENHWSW     "md5c_output_golden_HWSW.txt"
#define MD5C_OUTFILENAME_GOLDENSW       "md5c_output_golden_SW.txt"


#define MD5C_OUTFILENAMEHWSW            "md5c_output_HWSW.txt"
#define MD5C_OUTFILENAMESW              "md5c_output_SW.txt"

#define MD5C_DIFFFILENAMEHWSW           "md5c_diff_HWSW.txt"
#define MD5C_DIFFFILENAMESW             "md5c_diff_SW.txt"

//***************************************************************************************adpcm

#define ADPCM_INFILENAME                 "adpcm_input.txt"      // random

#define ADPCM_OUTFILENAME_GOLDENHWSW     "adpcm_output_golden_HWSW.txt"
#define ADPCM_OUTFILENAME_GOLDENSW       "adpcm_output_golden_SW.txt"


#define ADPCM_OUTFILENAMEHWSW            "adpcm_output_HWSW.txt"
#define ADPCM_OUTFILENAMESW              "adpcm_output_SW.txt"

#define ADPCM_DIFFFILENAMEHWSW           "adpcm_diff_HWSW.txt"
#define ADPCM_DIFFFILENAMESW             "adpcm_diff_SW.txt"

//***************************************************************************************  interp
#define INTERP_TAPS 8

#define INTERP_INFILTERFILENAME             "interp_in_data.txt"   // random data
#define INTERP_INCOEFFFILENAME              "interp_coeff.txt"

#define INTERP_OUTFILENAME_GOLDENHWSW       "interp_output_golden_HWSW.txt"
#define INTERP_OUTFILENAME_GOLDENSW         "interp_output_golden_SW.txt"

#define INTERP_OUTFILENAMEHWSW              "interp_output_HWSW.txt"
#define INTERP_OUTFILENAMESW                "interp_output_SW.txt"

#define INTERP_DIFFFILENAMEHWSW             "interp_diff_HWSW.txt"
#define INTERP_DIFFFILENAMESW               "interp_diff_SW.txt"

typedef int LONG;
typedef unsigned short WORD;
typedef unsigned int DWORD;
typedef char BYTE;

#pragma pack(push,1)
typedef struct {
  WORD  bfType;                       // The type of the image

  DWORD bfSize;                       //size of the file
  WORD  bfReserved;                 // reserved type
  WORD  bfReserved2;
  DWORD bfOffBits;                   //offset bytes from the file header to the image data
} BITMAPFILEHEADER, *PBITMAPFILEHEADER;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct tagBITMAPINFOHEADER {
  DWORD biSize;                   //the size of the header
  LONG  biWidth;                 //the width in pixels
  LONG  biHeight;                //the height in pixels
  WORD  biPlanes;                //the no. of planes in the bitmap
  WORD  biBitCount;              //bits per pixel
  DWORD biCompression;           //compression specifications
  DWORD biSizeImage;            //size of the bitmap data
  LONG  biXPelsPerMeter;        //horizontal res(pixels per meter)
  LONG  biYPelsPerMeter;        //vertical res(pixels per meter)
  DWORD biClrUsed;              //colours used in the image
  DWORD biClrImportant;        //num of important colours used
} BITMAPINFOHEADER, *PBITMAPINFOHEADER;
#pragma pack(pop)




// QSyS dependent address
#define FPGA_LED_PIO_BASE   0x10000
#define FPGA_KEY_PIO_BASE   0x10010
#define FPGA_SW_PIO_BASE    0x10040
#define FPGA_HEX_BASE       0x10060

#define FPGA_VIP_CTI_BASE    0x10080
#define FPGA_VIP_MIX_BASE    0x10100
#define FPGA_IR_RX_BASE      0x10200


#define UUT_IO_0_BASE        0x20000 //sobel
#define UUT_IO_1_BASE        0x21000 //fir
#define UUT_IO_2_BASE        0x22000 //qsort
#define UUT_IO_3_BASE        0x23000 //adpcm
#define UUT_IO_4_BASE        0x24000 //kasumi
#define UUT_IO_5_BASE        0x25000 //aes cipher
#define UUT_IO_6_BASE        0x26000 //aes_decipher
#define UUT_IO_7_BASE        0x27000 //interp
#define UUT_IO_8_BASE        0x28000 //snow3g
#define UUT_IO_9_BASE        0x29000 //md5c
#define UUT_IO_10_BASE       0x2A000


#define VALID_OUT_0_BASE    0x30000
#define VALID_OUT_1_BASE    0x31000
#define VALID_OUT_2_BASE    0x32000
#define VALID_OUT_3_BASE    0x33000
#define VALID_OUT_4_BASE    0x34000
#define VALID_OUT_5_BASE    0x35000
#define VALID_OUT_6_BASE    0x36000
#define VALID_OUT_7_BASE    0x37000
#define VALID_OUT_8_BASE    0x38000
#define VALID_OUT_9_BASE    0x39000
#define VALID_OUT_10_BASE   0x3A000

//#define FPGA_ADC_SPI_BASE   0x40040



// ///////////////////////////////////////
// memory map

#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

// ///////////////////////////////////////////////////
// SPI Micro
#define ALTERA_AVALON_SPI_RXDATA_REG                  0
#define ALTERA_AVALON_SPI_TXDATA_REG                  1
#define ALTERA_AVALON_SPI_STATUS_REG                  2
#define ALTERA_AVALON_SPI_CONTROL_REG                 3
#define ALTERA_AVALON_SPI_SLAVE_SEL_REG               5
#define IORD(base, index)                             (*( ((uint32_t *)base)+index))
#define IOWR(base, index, data)                       (*(((uint32_t *)base)+index) = data)
#define IORD_ALTERA_AVALON_SPI_RXDATA(base)           IORD(base, ALTERA_AVALON_SPI_RXDATA_REG)
#define IORD_ALTERA_AVALON_SPI_STATUS(base)           IORD(base, ALTERA_AVALON_SPI_STATUS_REG)
#define IOWR_ALTERA_AVALON_SPI_SLAVE_SEL(base, data)  IOWR(base, ALTERA_AVALON_SPI_SLAVE_SEL_REG, data)
#define IOWR_ALTERA_AVALON_SPI_CONTROL(base, data)    IOWR(base, ALTERA_AVALON_SPI_CONTROL_REG, data)
#define IOWR_ALTERA_AVALON_SPI_TXDATA(base, data)     IOWR(base, ALTERA_AVALON_SPI_TXDATA_REG, data)

#define ALTERA_AVALON_SPI_STATUS_ROE_MSK              (0x8)
#define ALTERA_AVALON_SPI_STATUS_ROE_OFST             (3)
#define ALTERA_AVALON_SPI_STATUS_TOE_MSK              (0x10)
#define ALTERA_AVALON_SPI_STATUS_TOE_OFST             (4)
#define ALTERA_AVALON_SPI_STATUS_TMT_MSK              (0x20)
#define ALTERA_AVALON_SPI_STATUS_TMT_OFST             (5)
#define ALTERA_AVALON_SPI_STATUS_TRDY_MSK             (0x40)
#define ALTERA_AVALON_SPI_STATUS_TRDY_OFST            (6)
#define ALTERA_AVALON_SPI_STATUS_RRDY_MSK             (0x80)
#define ALTERA_AVALON_SPI_STATUS_RRDY_OFST            (7)
#define ALTERA_AVALON_SPI_STATUS_E_MSK                (0x100)
#define ALTERA_AVALON_SPI_STATUS_E_OFST               (8)


#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )


#endif
