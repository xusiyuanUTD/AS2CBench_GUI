#include "define.h"


  //File pointers
  FILE * in_filter_file, *in_coeff_file, *out_filter_golden_file, *out_filter_file_read;
  FILE  *out_filter_file, *diff_file;



// Filter function

unsigned int MainWindow::fir_filter(
    unsigned int  *ary,
    unsigned int  *coeff)
{
    unsigned int sop=0;
    unsigned int filter_result ;
    unsigned char out;
    int i ;


    // Sum of product (SOP) generation
    for(i=0;i<FILTER_TAPS-1;i++){
        sop += ary[i] * coeff[i] ;
    }

    // Sign adjustment and rounding to sc_unit <8>)
    if ( sop < 0 ){
        sop = 0 ;
    }




   out = (unsigned char)(sop);
   filter_result =(unsigned int)out;
    return filter_result;
}

//---------------------------------
// Compare results function
//--------------------------------
void  MainWindow::fir_compare_results(bool hwsw){

  int outfilter, outfilter_golden, line=1, errors=0;
 char szText[64];
  // Close file where outputs are stored
 // fclose(out_filter_file);

  // Open results file
  if(hwsw){
  out_filter_file = fopen (FIR_OUTFILENAMEHWSW, "rt");}
  else{
      out_filter_file = fopen (FIR_OUTFILENAMESW, "rt");}


  if(!out_filter_file){
   printf(" Could not open  FIR_OUTFILENAME " ) ;
    exit (-1);
  }

    //
    //Load the golden output from file
    if(hwsw){
    out_filter_golden_file = fopen (FIR_OUTFILENAME_GOLDENHWSW, "rt");}
    else{
        out_filter_golden_file = fopen (FIR_OUTFILENAME_GOLDENSW, "rt");}


    if(!out_filter_golden_file){
   printf("    Could not open FIR_OUTFILENAME_GOLDEN  ");
      exit (-1);
     }

    //
    // comparison result with golden output
    //
    if(hwsw) {
    diff_file = fopen (FIR_DIFFFILENAMEHWSW, "w"); }
    else {
    diff_file = fopen (FIR_DIFFFILENAMESW, "w"); }


    if(!diff_file){
    printf("  Could not open  FIR_DIFFFILENAME  " );
     exit (-1);
       }

    //      while(out_filter_golden_file.eof()){
    while(fscanf(out_filter_golden_file, "%d", &outfilter_golden) != EOF){
      fscanf(out_filter_file,"%d", &outfilter);



       if(outfilter != outfilter_golden){

         fprintf(diff_file,"\nOutput missmatch[line:%d] Golden: %d -- Output: %d",line, outfilter_golden, outfilter);

         if(hwsw) sprintf(szText,"fir(ARM+FPGA)::Output missmatch[line:%d] Golden: %d -- Output: %d",line, outfilter_golden, outfilter);
         else sprintf(szText,"fir(ARM)::Output missmatch[line:%d] Golden: %d -- Output: %d",line, outfilter_golden, outfilter);
         ui->textBrowser->append(szText);
         errors++;
       }

          line ++;

    }

    if(errors == 0){
       if(hwsw)  ui->textBrowser->append("Finished FIR Filter ARM+FPGA simulation SUCCESSFULLY !! " );
       else  ui->textBrowser->append("Finished FIR Filter Pure ARM simulation SUCCESSFULLY !! " );
    }

    else{

       if(hwsw) sprintf(szText, "fir(ARM+FPGA)::MISMATCH :: %u out of %u ",errors,line);
       else sprintf(szText, "fir(ARM)::MISMATCH :: %u out of %u ",errors,line);
        ui->textBrowser->append(szText);



    }


    fclose(out_filter_file);
    fclose(diff_file);
    fclose(out_filter_golden_file);



}


//--------------------------
// Send data thread
//--------------------------
void MainWindow::fir_send(bool hwsw){

  // Variables declaration
  int i=0;
  unsigned int coeff_read[FILTER_TAPS], in_filter_read[FILTER_TAPS];
  unsigned int filter_out_write=0;
  int read;
   char szText[64];



    if((index.compare("Default File")==0) | (index.compare("Select File...")==0) ) {//open file
  ui->progressBar->setRange(0,FILTER_TAPS);


  if(hwsw){
  // out_filter_file.open (FIR_OUTFILENAMEHWSW);
  out_filter_file = fopen (FIR_OUTFILENAMEHWSW, "wt");
   }
  else {
  out_filter_file = fopen (FIR_OUTFILENAMESW, "wt");

    }


  //Reset routine
 if(index.compare("Default File")==0 ){ in_filter_file = fopen(FIR_INFILTERFILENAME, "rt");}
 else if(index.compare("Select File...")==0){in_filter_file = fopen(ui->textEdit_fir->toPlainText().toLatin1().data(), "rt");}

  in_coeff_file = fopen(FIR_INCOEFFFILENAME, "rt");


  if(!in_filter_file){
   printf(" Could not open  FIR_INFILTERFILENAME   " );
    exit (-1);
  }


  if(!in_coeff_file){
    printf( " Could not open  FIR_INCOEFFFILENAME   ");
    exit (-1);
  }

  if(!out_filter_file){
    printf("  Could not open  FIR_OUTFILENAME   " );
    exit (-1);
  }

  for(i=0; i < FILTER_TAPS; i++){
    if(fscanf(in_coeff_file, "%u", &coeff_read[i]) == EOF) break;
    if(hwsw) alt_write_word(h2p_lw_UUT_addr,coeff_read[i]);

    sprintf(szText, "%u \r", coeff_read[i]);
    //ui->textBrowsercoeff->append(szText);
   // sleep(1000);
    //  delay_s(1);

  }


    i=0;

         while(fscanf(in_filter_file,"%u", &in_filter_read[i]) != EOF){


        if(hwsw) alt_write_word(h2p_lw_UUT_addr,in_filter_read[i]);

        sprintf(szText, "%u \r", in_filter_read[i]);
        //ui->textBrowserin->append(szText);
        //delay_s(1);

    //printf("in_filter_read is %d\n",in_filter_read);
        i++;

        ui->progressBar->setValue(i);

    if(i==FILTER_TAPS)
                {
            i=0;

       if(hwsw){

            while(1){
             read=alt_read_word(h2p_lw_outvalid_addr);
             if(read)
            {
             alt_write_word(h2p_lw_outvalid_addr,true);
             filter_out_write = alt_read_word(h2p_lw_UUT_addr);
             fprintf(out_filter_file,"%d\n",filter_out_write);
            // printf("output is %d\n",filter_out_write);
             sprintf(szText, "%u \r", filter_out_write);
             //ui->textBrowserout->append(szText);
              //  delay_s(1);
             break;
            }

            } }

       else {
        filter_out_write = fir_filter(in_filter_read, coeff_read);
                fprintf(out_filter_file,"%d\n",filter_out_write);
                sprintf(szText, "%u \r", filter_out_write);
                //ui->textBrowserout->append(szText);
                 //  delay_s(1);
        }

                }






    }

 ui->progressBar->setValue(FILTER_TAPS);
    fclose(in_coeff_file);
    fclose(in_filter_file);
    fclose(out_filter_file);
    if(index.compare("Default File")==0 ){
    if(hwsw) fir_compare_results(true);
    else fir_compare_results(false);  }

    }

    else if(index.compare("Random")==0 ) {//open file --- don't need to compare

           ui->progressBar->setRange(0,index_val-1);

        for(int index_yy=0;index_yy<FILTER_TAPS;index_yy++){
         if(hwsw)  alt_write_word(h2p_lw_UUT_addr,rand()%255);
         else coeff_read[index_yy] = rand()%255;
     }



             for(unsigned long index_xx=0;index_xx<index_val;index_xx++) {

                 ui->progressBar->setValue(index_xx);

                 for(int index_yy=0;index_yy<FILTER_TAPS;index_yy++){
                  if(hwsw)  alt_write_word(h2p_lw_UUT_addr,rand()%255);
                  else in_filter_read[index_yy] = rand()%255;
              }

                 if(hwsw){

                      while(1){
                       read=alt_read_word(h2p_lw_outvalid_addr);
                       if(read)
                      {
                       alt_write_word(h2p_lw_outvalid_addr,true);
                       filter_out_write = alt_read_word(h2p_lw_UUT_addr);

                       break;
                      }

                      } }

                 else {
                  filter_out_write = fir_filter(in_filter_read, coeff_read);

                  }

                  // qDebug()<< in_filter_read[0] <<"\n";
                  // qDebug()<< "output is "<<  filter_out_write ;

             }

    }

    }


//--------------------------
// Main function
//--------------------------


void  MainWindow::fir_main(bool hwsw,bool single_double) //0:ARM 1:ARM+FPGA
{


    void *virtual_base;
    int fd;
    QPixmap pixmap;
    GET_TIME_INIT(3);
    char szText[64];
    double compare_t[2];
    double compare_bool;

        if(hwsw)  { //ARM+FPGA
    // map the address space for the LED registers into user space so we can interact with them.
    // we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
    if( ( fd = ::open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );

    }
    virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        ::close( fd );

    }
    h2p_lw_UUT_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_1_BASE) & ( unsigned long)( HW_REGS_MASK ) );
    h2p_lw_outvalid_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + VALID_OUT_1_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
    if(single_double){
        ui->textBrowser->append("Start the  FIR Filter simulation...");
          fprintf(as2cbench,"Start the  FIR Filter simulation...\n");

        GET_TIME_VAL(0);
        fir_send(false);  //ARM
        GET_TIME_VAL(1);
        fir_send(true);  //ARM+FPGA
        GET_TIME_VAL(2);

        compare_t[0]=(TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0;
        compare_t[1]=(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0;

        compare_bool=(compare_t[0]-compare_t[1])/compare_t[0];
        compare_bool=(compare_bool*100); //==> 100%
        ui->textBrowser->append("End of the  FIR Filter simulation..");
        ui->textBrowser->append("  ");
        ui->textBrowser->append("   FIR Filter Simulation Results: ");
        ui->textBrowser->append(" -------------------------------------------- ");
        ui->textBrowser->append("   Pure ARM     ||     ARM+FPGA  : ");
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "FIR Accelerated %0.2lf%%",compare_bool);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" ----------------------------------------------------------- ");

        fprintf(as2cbench,"End of the FIR Filter simulation..\n");
        fprintf(as2cbench,"  \n");
        fprintf(as2cbench,"   FIR Filter Simulation Results: \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        fprintf(as2cbench,"   Pure ARM     ||     ARM+FPGA  : \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "Accelerated %0.2lf%%\n",compare_bool);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," ----------------------------------------------------------- \n");
    }


    else{
        ui->textBrowser->append("Start the FIR Filter ARM+FPGA simulation...");
          fprintf(as2cbench,"Start the  FIR Filter ARM+FPGA simulation...\n");
    GET_TIME_VAL(0);
    fir_send(true);  //ARM+FPGA
    GET_TIME_VAL(1);
    ui->textBrowser->append("End of the  FIR Filter ARM+FPGA simulation..");
     fprintf(as2cbench,"End of the  FIR Filter ARM+FPGA simulation..\n");

    sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
    ui->textBrowser->append(szText);
    fprintf(as2cbench,szText);

    }
    if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
        printf( "ERROR: munmap() failed...\n" );
        ::close( fd );

    }

    ::close( fd );  }


        else {
            ui->textBrowser->append("Start the  FIR Filter ARM simulation...");
              fprintf(as2cbench,"Start the  FIR Filter ARM simulation...\n");
            GET_TIME_VAL(0);
            fir_send(false);  //ARM
            GET_TIME_VAL(1);
            ui->textBrowser->append("End of the  FIR Filter ARM simulation..");
             fprintf(as2cbench,"End of the  FIR Filter ARM simulation..\n");

            sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
            ui->textBrowser->append(szText);
             fprintf(as2cbench,szText);

    }




}
