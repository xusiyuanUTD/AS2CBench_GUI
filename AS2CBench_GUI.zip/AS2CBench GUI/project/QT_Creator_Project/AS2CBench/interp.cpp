
#include "define.h"

   // Variables
   int buffer[INTERP_TAPS] ;

   int indata_read;
   int infactor_read;
   int odata_write;
   int SoP1;
   int SoP2;
   int SoP3;
   int SoP4;


     const int coeff1[INTERP_TAPS] = {26 , -375 ,2613 , 2366 , -175 , 37 , 407 , -64  };

     const int coeff2[INTERP_TAPS] = {-12, -99 , 2833 , -3876 , 109 ,112 , -109 , 2833	};

     const int coeff3[INTERP_TAPS] = {-254 , 1237 ,-877,  -894 , 4443 , -172 ,1117 ,2223 };

     const int coeff4[INTERP_TAPS] = {-224 , 562 ,-5623 , 3429 , -782 ,34 , 456 ,1 	};

  // Variables declaration
  FILE *interp_fptr_data;
  FILE *interp_in_file_data, *interp_in_file_factor;
  FILE  *interp_diff_file;


//--------------------------------
// Compare simulation results vs. golden output
//--------------------------------

void MainWindow::interp_compare_results(bool hwsw){

  // Variables declaration
  int outfilter_golden,outfilter;
  int errors, line;
  FILE *out_fil_golden;
  char szText[64];



  if(hwsw) interp_fptr_data = fopen(INTERP_OUTFILENAMEHWSW, "rt");
  else  interp_fptr_data = fopen(INTERP_OUTFILENAMESW, "rt");
 
  line =1;
  errors = 0;



  if(hwsw) out_fil_golden = fopen(INTERP_OUTFILENAME_GOLDENHWSW , "rt");
  else out_fil_golden = fopen(INTERP_OUTFILENAME_GOLDENSW , "rt");

  if(!out_fil_golden){
    printf( "Could not open  INTERP_OUTFILENAME_GOLDENHWSW \n" );
  }
  if(hwsw) {
  interp_diff_file = fopen (INTERP_DIFFFILENAMEHWSW, "w"); }
  else {
  interp_diff_file = fopen (INTERP_DIFFFILENAMESW, "w"); }

  while(fscanf(out_fil_golden, "%d", &outfilter_golden)!= EOF && fscanf(interp_fptr_data, "%d", &outfilter) != EOF ){
 
    if(outfilter!= outfilter_golden){
        fprintf(interp_diff_file,"\nOutput missmatch[line:%d] Golden: %d -- Output: %d",line, outfilter_golden, outfilter);

        if(hwsw) sprintf(szText,"interp(ARM+FPGA)::Output missmatch[line:%d] Golden: %d -- Output: %d",line, outfilter_golden, outfilter);
        else sprintf(szText,"interp(ARM)::Output missmatch[line:%d] Golden: %d -- Output: %d",line, outfilter_golden, outfilter);
        ui->textBrowser->append(szText);
      errors++;
    }

    line++;

  }

  if(errors == 0){
     if(hwsw)  ui->textBrowser->append("Finished Interp ARM+FPGA simulation SUCCESSFULLY !! " );
     else  ui->textBrowser->append("Finished Interp Pure ARM simulation SUCCESSFULLY !! " );
  }

  else{
     if(hwsw) sprintf(szText, "interp(ARM+FPGA)::MISMATCH :: %u out of %u ",errors,line);
     else sprintf(szText, "interp(ARM)::MISMATCH :: %u out of %u ",errors,line);
      ui->textBrowser->append(szText);



  }
  fclose(out_fil_golden);
  fclose(interp_fptr_data);
  fclose(interp_diff_file);
}



//----------------------
// Send data to Interpolation Filter
//----------------------------
void MainWindow::interp_send(bool hwsw){

  // Variables declarations
  int indata_var=0;
  int  infactor_var=0;
  int k,n;
  int z;
  int read=0;
  int odata_rcv;
  int outdata;
  int count=0;


  if((index.compare("Default File")==0 )| (index.compare("Select File...")==0) ) {//open file


   ui->progressBar->setRange(0,100);
  if(hwsw) interp_fptr_data = fopen(INTERP_OUTFILENAMEHWSW , "wt");
  else interp_fptr_data = fopen(INTERP_OUTFILENAMESW , "wt");

 
  if(!interp_fptr_data){
   printf(" could not be opened output \n" );
 
  }


   //Reset initialization
  // interp_in_file_data = fopen(INTERP_INFILTERFILENAME, "r");
  if(index.compare("Default File")==0 ){ interp_in_file_data = fopen(INTERP_INFILTERFILENAME, "r");}
  else if(index.compare("Select File...")==0){interp_in_file_data = fopen(ui->textEdit_interp->toPlainText().toLatin1().data(), "rt");}


   interp_in_file_factor = fopen( INTERP_INCOEFFFILENAME, "r");

   if(!interp_in_file_data){
     printf( "data file could not be opened \n");
    }

   if(!interp_in_file_factor){
     printf( " file could not be opened \n " );;

   }



    while(fscanf(interp_in_file_data,"%d",&indata_var) !=EOF &&  fscanf(interp_in_file_factor,"%d", &infactor_var) != EOF){
     
    count++;
     ui->progressBar->setValue(count);
	      // Read inputs
        if(hwsw) { alt_write_word(h2p_lw_UUT_addr,indata_var);
            alt_write_word(h2p_lw_UUT_addr,infactor_var);

            while(1){
             read=alt_read_word(h2p_lw_outvalid_addr);
             if(read)
            {
             alt_write_word(h2p_lw_outvalid_addr,true);
             outdata = alt_read_word(h2p_lw_UUT_addr);
             fprintf(interp_fptr_data,"%d\n",outdata);
             break;
            }

            }


        }
        else {
      indata_read = indata_var;
      infactor_read = infactor_var;

    // Read inputs by shifting previous data
    for ( n = 5; n>0; n--)
         buffer[n] = buffer[n-1];
      buffer[0] = indata_read;
  
   
      // interp 1 : Sum of Products of 1st filter
      SoP1 = 0;
      for (n = 0; n < INTERP_TAPS; n++ ) 
	SoP1 = SoP1 + buffer[n] * coeff1[n];
      
      // interp 2 : Sum of Products of 2nd filter
      SoP2 = 0;
      for (n = 0; n < INTERP_TAPS; n++ ) 
	SoP2 =SoP2 + buffer[n] * coeff2[n];

      // interp 3 : Sum of Products of 3rd filter
      SoP3 = 0;
      for ( n = 0; n < INTERP_TAPS; n++ ) 
	SoP3 = SoP3 + buffer[n] * coeff3[n];

      // interp 4 : Sum of Products of 4th filter
      SoP4 = 0;
      for (n = 0; n < INTERP_TAPS; n++ ) 
	SoP4 = SoP4 + buffer[n] * coeff4[n];


   // Output computation 
   odata_write = SoP1 +
               SoP2 * infactor_read +
               SoP3 * infactor_read*infactor_read + 
               SoP4 * infactor_read*infactor_read*infactor_read;




     // Write results back

    outdata=odata_write;
    fprintf(interp_fptr_data,"%d\n",outdata); }


    }


    fclose(interp_in_file_data);
    fclose(interp_in_file_factor);
     fclose(interp_fptr_data);
        ui->progressBar->setValue(100);

    if(index.compare("Default File")==0 ){
    if(hwsw) interp_compare_results(true);
    else interp_compare_results(false);  }  }


  else if(index.compare("Random")==0 ) {//open file --- don't need to compare


     ui->progressBar->setRange(0,index_val-1);

           for(unsigned long index_xx=0;index_xx<index_val;index_xx++) {

               ui->progressBar->setValue(index_xx);

                     // Read inputs
               if(hwsw) { alt_write_word(h2p_lw_UUT_addr,rand()%255);
                       alt_write_word(h2p_lw_UUT_addr,rand()%255);

                       while(1){
                        read=alt_read_word(h2p_lw_outvalid_addr);
                        if(read)
                       {
                        alt_write_word(h2p_lw_outvalid_addr,true);
                        outdata = alt_read_word(h2p_lw_UUT_addr);
                       // fprintf(interp_fptr_data,"%d\n",outdata);
                        break;
                       }

                       }


                   }
                   else {
                 indata_read = rand()%255;
                 infactor_read = rand()%255;

               // Read inputs by shifting previous data
               for ( n = 5; n>0; n--)
                    buffer[n] = buffer[n-1];
                 buffer[0] = indata_read;


                 // interp 1 : Sum of Products of 1st filter
                 SoP1 = 0;
                 for (n = 0; n < INTERP_TAPS; n++ )
               SoP1 = SoP1 + buffer[n] * coeff1[n];

                 // interp 2 : Sum of Products of 2nd filter
                 SoP2 = 0;
                 for (n = 0; n < INTERP_TAPS; n++ )
               SoP2 =SoP2 + buffer[n] * coeff2[n];

                 // interp 3 : Sum of Products of 3rd filter
                 SoP3 = 0;
                 for ( n = 0; n < INTERP_TAPS; n++ )
               SoP3 = SoP3 + buffer[n] * coeff3[n];

                 // interp 4 : Sum of Products of 4th filter
                 SoP4 = 0;
                 for (n = 0; n < INTERP_TAPS; n++ )
               SoP4 = SoP4 + buffer[n] * coeff4[n];


              // Output computation
              odata_write = SoP1 +
                          SoP2 * infactor_read +
                          SoP3 * infactor_read*infactor_read +
                          SoP4 * infactor_read*infactor_read*infactor_read;

                // Write results back

               outdata=odata_write;
               //fprintf(interp_fptr_data,"%d\n",outdata);
               }


               }


           }



 

}

//--------------------------
// Main function
//--------------------------


void  MainWindow::interp_main(bool hwsw,bool single_double) //0:ARM 1:ARM+FPGA
{


    void *virtual_base;
    int fd;
    QPixmap pixmap;
    GET_TIME_INIT(3);
    char szText[64];
    double compare_t[2];
    double compare_bool;

        if(hwsw)  { //ARM+FPGA
    // map the address space for the LED registers into user space so we can interact with them.
    // we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
    if( ( fd = ::open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );

    }
    virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        ::close( fd );

    }
    h2p_lw_UUT_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_7_BASE) & ( unsigned long)( HW_REGS_MASK ) );
    h2p_lw_outvalid_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + VALID_OUT_7_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
    if(single_double){
        ui->textBrowser->append("Start the  interp Filter simulation...");
          fprintf(as2cbench,"Start the  interp Filter simulation...\n");

        GET_TIME_VAL(0);
        interp_send(false);  //ARM
        GET_TIME_VAL(1);
        interp_send(true);  //ARM+FPGA
        GET_TIME_VAL(2);

        compare_t[0]=(TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0;
        compare_t[1]=(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0;

        compare_bool=(compare_t[0]-compare_t[1])/compare_t[0];
        compare_bool=(compare_bool*100); //==> 100%
        ui->textBrowser->append("End of the  interp Filter simulation..");
        ui->textBrowser->append("  ");
        ui->textBrowser->append("   interp Filter Simulation Results: ");
        ui->textBrowser->append(" -------------------------------------------- ");
        ui->textBrowser->append("   Pure ARM     ||     ARM+FPGA  : ");
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "interp Accelerated %0.2lf%%",compare_bool);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" ----------------------------------------------------------- ");

        fprintf(as2cbench,"End of the interp Filter simulation..\n");
        fprintf(as2cbench,"  \n");
        fprintf(as2cbench,"   interp Filter Simulation Results: \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        fprintf(as2cbench,"   Pure ARM     ||     ARM+FPGA  : \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "Accelerated %0.2lf%%\n",compare_bool);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," ----------------------------------------------------------- \n");
    }


    else{
        ui->textBrowser->append("Start the interp Filter ARM+FPGA simulation...");
          fprintf(as2cbench,"Start the  interp Filter ARM+FPGA simulation...\n");
    GET_TIME_VAL(0);
    interp_send(true);  //ARM+FPGA
    GET_TIME_VAL(1);
    ui->textBrowser->append("End of the  interp Filter ARM+FPGA simulation..");
     fprintf(as2cbench,"End of the  interp Filter ARM+FPGA simulation..\n");

    sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
    ui->textBrowser->append(szText);
    fprintf(as2cbench,szText);

    }
    if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
        printf( "ERROR: munmap() failed...\n" );
        ::close( fd );

    }

    ::close( fd );  }


        else {
            ui->textBrowser->append("Start the  interp Filter ARM simulation...");
              fprintf(as2cbench,"Start the  interp Filter ARM simulation...\n");
            GET_TIME_VAL(0);
            interp_send(false);  //ARM
            GET_TIME_VAL(1);
            ui->textBrowser->append("End of the  interp Filter ARM simulation..");
             fprintf(as2cbench,"End of the  interp Filter ARM simulation..\n");

            sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
            ui->textBrowser->append(szText);
             fprintf(as2cbench,szText);

    }




}


