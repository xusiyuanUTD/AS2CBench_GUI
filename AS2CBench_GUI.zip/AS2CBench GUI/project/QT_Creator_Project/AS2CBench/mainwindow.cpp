#include "mainwindow.h"
#include "ui_mainwindow.h"
//#include "QCheckBox"

#include <QtGui>
#include <QPainter>

#include <QLabel>
#include <QLineEdit>
#include <QProgressBar>
#include <QComboBox>
#include <QPushButton>
#include <QGridLayout>
#include <QProgressDialog>
#include <QFont>
#include "timer.h"
#include <QDebug>




MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->progressBar->setValue(0);
  //  this->setAttribute(Qt::WA_TranslucentBackground,true);
    ui->comboBox->addItem(QWidget::tr("Default File"));
    ui->comboBox->addItem(QWidget::tr("Random"));
    ui->comboBox->addItem(QWidget::tr("Select File..."));

    ui->textEdit_sobel->setWordWrapMode(QTextOption::NoWrap);
    ui->textEdit_qsort->setWordWrapMode(QTextOption::NoWrap);
    ui->textEdit_fir->setWordWrapMode(QTextOption::NoWrap);
    ui->textEdit_aes->setWordWrapMode(QTextOption::NoWrap);
    ui->textEdit_aesde->setWordWrapMode(QTextOption::NoWrap);
    ui->textEdit_snow3g->setWordWrapMode(QTextOption::NoWrap);
    ui->textEdit_kasumi->setWordWrapMode(QTextOption::NoWrap);
    ui->textEdit_md5c->setWordWrapMode(QTextOption::NoWrap);
    ui->textEdit_adpcm->setWordWrapMode(QTextOption::NoWrap);
    ui->textEdit_interp->setWordWrapMode(QTextOption::NoWrap);


    ui->checkBox_all->setStyleSheet("QCheckBox::indicator{width:25px;height:25px;}");
    ui->checkBox_ARM->setStyleSheet("QCheckBox::indicator{width:25px;height:25px;}");
    ui->checkBox_ARMFPGA->setStyleSheet("QCheckBox::indicator{width:25px;height:25px;}");
    ui->bench_9->setChecked(false);

        as2cbench = fopen ("as2cbench.log", "wt");

    ui->textBrowser->append("========================================================================================");
    ui->textBrowser->append(" AS2CBench :Accelerated Synthesizable SystemC Benchmark suite       ");
    ui->textBrowser->append(" Copyright PolyU ");
    ui->textBrowser->append(" Author: B.Carrion Schafer, Siyuan XU");
    ui->textBrowser->append(" Version V1.0  ");
    ui->textBrowser->append("   ");
    ui->textBrowser->append(" Most of the work has been done by the DARClab at the Hong Kong Polytechnic Universities ");
    ui->textBrowser->append(" Department of Electronic and Information Engineering (EIE)  ");
    ui->textBrowser->append(" DARClab =Design Automation and Reconfigurable Computing Laboratory - www.eie.polyu.edu.hk/~schaferb/darclab ");
    ui->textBrowser->append("   ");
    ui->textBrowser->append("AS2CBench is distributed in the hope that it will be useful. AS2CBench is free software and hardware; ");
    ui->textBrowser->append("you can redistribute it and/or modify it, but please remember but WITHOUT ANY WARRANTY; without even the ");
    ui->textBrowser->append("implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. ");
    ui->textBrowser->append("=========================================================================================");
  //  ui->textBrowser->append("   ");
  //  ui->textBrowser->append("   ");

    fprintf(as2cbench,"========================================================================================\n");
    fprintf(as2cbench," AS2CBench :Accelerated Synthesizable SystemC Benchmark suite       \n");
    fprintf(as2cbench," Copyright PolyU \n");
    fprintf(as2cbench," Author: B.Carrion Schafer, Siyuan XU\n");
    fprintf(as2cbench," Version V1.0  \n");
    fprintf(as2cbench,"   \n");
    fprintf(as2cbench," Most of the work has been done by the DARClab at the Hong Kong Polytechnic Universities \n");
    fprintf(as2cbench," Department of Electronic and Information Engineering (EIE)  \n");
    fprintf(as2cbench," DARClab =Design Automation and Reconfigurable Computing Laboratory - www.eie.polyu.edu.hk/~schaferb/darclab \n");
    fprintf(as2cbench,"   \n");
    fprintf(as2cbench,"AS2CBench is distributed in the hope that it will be useful. AS2CBench is free software and hardware; \n");
    fprintf(as2cbench,"you can redistribute it and/or modify it, but please remember but WITHOUT ANY WARRANTY; without even the \n");
    fprintf(as2cbench,"implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. \n");
    fprintf(as2cbench,"=========================================================================================\n");

    fclose(as2cbench);



   /* for(int i;i<100;i++){
     sprintf(szText, "%d", rand()%255);
      ui->textBrowser->append(szText);  }  */

    ui->textEdit_sobel->setText("lena512.bmp");
    ui->textEdit_fir->setText( "fir_in_data.txt");
    ui->textEdit_qsort->setText("qsort_in_data.txt");
    ui->textEdit_aes->setText("aes_cipher_input.txt");
    ui->textEdit_aesde->setText("aes_decipher_input.txt");
    ui->textEdit_kasumi->setText("snow_3G_input.txt" );
    ui->textEdit_md5c->setText(  "kasumi_indata.txt");
    ui->textEdit_snow3g->setText("md5c_input.txt");
    ui->textEdit_adpcm->setText("adpcm_input.txt" );
    ui->textEdit_interp->setText( "interp_in_data.txt" );


}

MainWindow::~MainWindow()
{

    delete ui;
}

void MainWindow::on_checkBox_all_clicked()
{

    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,
    };

    if(ui->checkBox_all->isChecked()){

       for(int i=0;i<10;i++){
         szCheck[i]->setChecked(true);
       }

    }
    else{
         for(int i=0;i<10;i++){
        szCheck[i]->setChecked(false);}

    }
}



void MainWindow::on_textBrowser_textChanged()
{
    ui->textBrowser->moveCursor(QTextCursor::End);
}

void MainWindow::on_pushButton_clicked()
{

    bool x[12];
    QCheckBox *szCheck[] = {
        ui->checkBox_sobel,
        ui->checkBox_fir,
        ui->checkBox_qsort,
        ui->checkBox_aes,
        ui->checkBox_aesde,
        ui->checkBox_kasumi,
        ui->checkBox_md5c,
        ui->checkBox_snow3g,
        ui->checkBox_adpcm,
        ui->checkBox_interp,

    };

    for(int i=0;i<10;i++){
       x[i]=false;
       x[i]=szCheck[i]->isChecked();
    }

   ui->textBrowser->setTextColor(Qt::black);

 //   qDebug() << index<< "\r\n";

    index=ui->comboBox->currentText();
     index_val=ui->spinBox->value()+1;

    ui->label_bmpin->clear( );
    ui->label_bmpout->clear( );

        as2cbench = fopen ("as2cbench.log", "at");


if(! ((index.compare("Random")==0) & (ui->spinBox->value()==0)) ) {



 if(!(ui->checkBox_ARM->isChecked()) && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM
    ui->textBrowser->setTextColor(Qt::red);
    ui->textBrowser->append("ERROR : Please select ARM or ARM+FPGA or both to run the Simulation !!! \n");
    ui->textBrowser->setTextColor(Qt::black);

}

 if(ui->checkBox_sobel->isChecked()){ //sobel

    ui->bench_9->setChecked(true);  //display BMP File


    if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

     sobel_main(false,false);
                                      }
    else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

        sobel_main(true,false);
                                         }

    else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

        sobel_main(true,true);
                                         }


 }

 if(ui->checkBox_fir->isChecked()){ //fir


  ui->bench_9->setChecked(false); //CLose Display the BMP file

     if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

      fir_main(false,false);
                                       }
     else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

         fir_main(true,false);
                                          }

     else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

         fir_main(true,true);
                                          }


  }

 if(ui->checkBox_qsort->isChecked()){ //qsort


  ui->bench_9->setChecked(false); //CLose Display the BMP file

     if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

      qsort_main(false,false);
                                       }
     else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

         qsort_main(true,false);
                                          }

     else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

         qsort_main(true,true);
                                          }


  }




 if(ui->checkBox_aes->isChecked()){ //aes


  ui->bench_9->setChecked(false); //CLose Display the BMP file

     if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

      aes_main(false,false);
                                       }
     else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

         aes_main(true,false);
                                          }

     else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

         aes_main(true,true);
                                          }


  }
 if(ui->checkBox_aesde->isChecked()){ //aes decipher


  ui->bench_9->setChecked(false); //CLose Display the BMP file

     if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

      aes_de_main(false,false);
                                       }
     else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

         aes_de_main(true,false);
                                          }

     else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

         aes_de_main(true,true);
                                          }


  }

 if(ui->checkBox_snow3g->isChecked()){ //snow3g


  ui->bench_9->setChecked(false); //CLose Display the BMP file

     if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

      snow3g_main(false,false);
                                       }
     else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

         snow3g_main(true,false);
                                          }

     else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

         snow3g_main(true,true);
                                          }


  }

 if(ui->checkBox_kasumi->isChecked()){ //snow3g


  ui->bench_9->setChecked(false); //CLose Display the BMP file

     if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

      kasumi_main(false,false);
                                       }
     else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

         kasumi_main(true,false);
                                          }

     else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

         kasumi_main(true,true);
                                          }


  }

 if(ui->checkBox_md5c->isChecked()){ //md5c


  ui->bench_9->setChecked(false); //CLose Display the BMP file

     if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

      md5c_main(false,false);
                                       }
     else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

         md5c_main(true,false);
                                          }

     else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

         md5c_main(true,true);
                                          }


  }

 if(ui->checkBox_adpcm->isChecked()){ //adpcm


  ui->bench_9->setChecked(false); //CLose Display the BMP file

     if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

      adpcm_main(false,false);
                                       }
     else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

        adpcm_main(true,false);
                                          }

     else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

         adpcm_main(true,true);
                                          }


  }

 if(ui->checkBox_interp->isChecked()){ //interp


  ui->bench_9->setChecked(false); //CLose Display the BMP file

     if(ui->checkBox_ARM->isChecked() && !(ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM

      interp_main(false,false);
                                       }
     else if (!(ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //only ARM+FPGA

        interp_main(true,false);
                                          }

     else if ((ui->checkBox_ARM->isChecked()) && (ui->checkBox_ARMFPGA->isChecked()) ){ //ARM+FPGA and ARM ~~ Two Version

         interp_main(true,true);
                                          }


  }

}

else {
    ui->textBrowser->setTextColor(Qt::red);
    ui->textBrowser->append("ERROR : For Random input, the number of TBs Must larger than 1 \n");
    ui->textBrowser->setTextColor(Qt::black);
}


 fclose(as2cbench);
}



void MainWindow::on_pushButton_sobel_clicked()
{
ui->textBrowser->setTextColor(Qt::black);
    index=ui->comboBox->currentText();

   if(index.compare("Select File...")==0) {//open file
    QString openPath;
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                      openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

    QByteArray ba=filePath.toLatin1();
    file_on_sobel=ba.data();
   // qDebug()<<file_on<<"\n";

    if (!(filePath.isEmpty())){
        ui->checkBox_sobel->setChecked(true);
        QFile *file=new QFile;
        file->setFileName(filePath);
        QFileInfo fileInfo(*file);
        ui->textBrowser->append("Choosing File From: ");
        ui->textBrowser->setTextColor(Qt::blue);
        ui->textBrowser->append(file_on_sobel);
        ui->textBrowser->setTextColor(Qt::black);
        ui->textEdit_sobel->setText(fileInfo.fileName());

    //  FILE * in_file;
     // unsigned int in_read;
     // in_file_sobel = fopen(file_on, "rt");
     // while(fscanf(in_file,"%u", &in_read) != EOF){
       //  qDebug()<<"in:"<<in_read<<"\n";
    // }

    }

   }
   else{
       ui->textBrowser->setTextColor(Qt::red);
       ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
       ui->textBrowser->setTextColor(Qt::black);

   }
}

void MainWindow::on_pushButton_fir_clicked()
{
  ui->textBrowser->setTextColor(Qt::black);
    index=ui->comboBox->currentText();

   if(index.compare("Select File...")==0) {//open file
    QString openPath;
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                      openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

    QByteArray ba=filePath.toLatin1();
    file_on_fir=ba.data();
   // qDebug()<<file_on<<"\n";

    if (!(filePath.isEmpty())){
        ui->checkBox_fir->setChecked(true);
        QFile *file=new QFile;
        file->setFileName(filePath);
        QFileInfo fileInfo(*file);
        ui->textBrowser->append("Choosing File From: ");
        ui->textBrowser->setTextColor(Qt::blue);
        ui->textBrowser->append(file_on_fir);
        ui->textBrowser->setTextColor(Qt::black);
        ui->textEdit_fir->setText(fileInfo.fileName());

     // FILE * in_file;
    //  unsigned int in_read;
    //  in_file = fopen(file_on_fir, "rt");
     // while(fscanf(in_file,"%u", &in_read) != EOF){
     //    qDebug()<<"in:"<<in_read<<"\n";
    // }

    }

   }
   else{
       ui->textBrowser->setTextColor(Qt::red);
       ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
       ui->textBrowser->setTextColor(Qt::black);

   }
}

void MainWindow::on_pushButton_qsort_clicked()
{
ui->textBrowser->setTextColor(Qt::black);
    index=ui->comboBox->currentText();

   if(index.compare("Select File...")==0) {//open file
    QString openPath;
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                      openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

    QByteArray ba=filePath.toLatin1();
    file_on_qsort=ba.data();
   // qDebug()<<file_on<<"\n";

    if (!(filePath.isEmpty())){
        ui->checkBox_qsort->setChecked(true);
        QFile *file=new QFile;
        file->setFileName(filePath);
        QFileInfo fileInfo(*file);
        ui->textBrowser->append("Choosing File From: ");
        ui->textBrowser->setTextColor(Qt::blue);
        ui->textBrowser->append(file_on_qsort);
        ui->textBrowser->setTextColor(Qt::black);
        ui->textEdit_qsort->setText(fileInfo.fileName());

    //  FILE * in_file;
     // unsigned int in_read;
     // in_file_sobel = fopen(file_on, "rt");
     // while(fscanf(in_file,"%u", &in_read) != EOF){
       //  qDebug()<<"in:"<<in_read<<"\n";
    // }

    }

   }
   else{
       ui->textBrowser->setTextColor(Qt::red);
       ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
       ui->textBrowser->setTextColor(Qt::black);

   }
}

void MainWindow::on_pushButton_aes_clicked()
{
ui->textBrowser->setTextColor(Qt::black);
    index=ui->comboBox->currentText();

   if(index.compare("Select File...")==0) {//open file
    QString openPath;
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                      openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

    QByteArray ba=filePath.toLatin1();
    file_on_aes=ba.data();
   // qDebug()<<file_on<<"\n";

    if (!(filePath.isEmpty())){
        ui->checkBox_aes->setChecked(true);
        QFile *file=new QFile;
        file->setFileName(filePath);
        QFileInfo fileInfo(*file);
        ui->textBrowser->append("Choosing File From: ");
        ui->textBrowser->setTextColor(Qt::blue);
        ui->textBrowser->append(file_on_aes);
        ui->textBrowser->setTextColor(Qt::black);
        ui->textEdit_aes->setText(fileInfo.fileName());

    //  FILE * in_file;
     // unsigned int in_read;
     // in_file_sobel = fopen(file_on, "rt");
     // while(fscanf(in_file,"%u", &in_read) != EOF){
       //  qDebug()<<"in:"<<in_read<<"\n";
    // }

    }

   }
   else{
       ui->textBrowser->setTextColor(Qt::red);
       ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
       ui->textBrowser->setTextColor(Qt::black);

   }
}

void MainWindow::on_pushButton_aesde_clicked()
{
ui->textBrowser->setTextColor(Qt::black);
    index=ui->comboBox->currentText();

   if(index.compare("Select File...")==0) {//open file
    QString openPath;
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                      openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

    QByteArray ba=filePath.toLatin1();
    file_on_aesde=ba.data();
   // qDebug()<<file_on<<"\n";

    if (!(filePath.isEmpty())){
        ui->checkBox_aesde->setChecked(true);
        QFile *file=new QFile;
        file->setFileName(filePath);
        QFileInfo fileInfo(*file);
        ui->textBrowser->append("Choosing File From: ");
        ui->textBrowser->setTextColor(Qt::blue);
        ui->textBrowser->append(file_on_aesde);
        ui->textBrowser->setTextColor(Qt::black);
        ui->textEdit_aesde->setText(fileInfo.fileName());

    //  FILE * in_file;
     // unsigned int in_read;
     // in_file_sobel = fopen(file_on, "rt");
     // while(fscanf(in_file,"%u", &in_read) != EOF){
       //  qDebug()<<"in:"<<in_read<<"\n";
    // }

    }

   }
   else{
       ui->textBrowser->setTextColor(Qt::red);
       ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
       ui->textBrowser->setTextColor(Qt::black);

   }
}

void MainWindow::on_pushButton_snow3g_clicked()
{
ui->textBrowser->setTextColor(Qt::black);
    index=ui->comboBox->currentText();

   if(index.compare("Select File...")==0) {//open file
    QString openPath;
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                      openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

    QByteArray ba=filePath.toLatin1();
    file_on_snow3g=ba.data();
   // qDebug()<<file_on<<"\n";

    if (!(filePath.isEmpty())){
        ui->checkBox_snow3g->setChecked(true);
        QFile *file=new QFile;
        file->setFileName(filePath);
        QFileInfo fileInfo(*file);
        ui->textBrowser->append("Choosing File From: ");
        ui->textBrowser->setTextColor(Qt::blue);
        ui->textBrowser->append(file_on_snow3g);
        ui->textBrowser->setTextColor(Qt::black);
        ui->textEdit_snow3g->setText(fileInfo.fileName());

    //  FILE * in_file;
     // unsigned int in_read;
     // in_file_sobel = fopen(file_on, "rt");
     // while(fscanf(in_file,"%u", &in_read) != EOF){
       //  qDebug()<<"in:"<<in_read<<"\n";
    // }

    }

   }
   else{
       ui->textBrowser->setTextColor(Qt::red);
       ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
       ui->textBrowser->setTextColor(Qt::black);

   }
}

void MainWindow::on_pushButton_kasumi_clicked()
{
ui->textBrowser->setTextColor(Qt::black);
    index=ui->comboBox->currentText();

   if(index.compare("Select File...")==0) {//open file
    QString openPath;
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                      openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

    QByteArray ba=filePath.toLatin1();
    file_on_kasumi=ba.data();
   // qDebug()<<file_on<<"\n";

    if (!(filePath.isEmpty())){
        ui->checkBox_kasumi->setChecked(true);
        QFile *file=new QFile;
        file->setFileName(filePath);
        QFileInfo fileInfo(*file);
        ui->textBrowser->append("Choosing File From: ");
        ui->textBrowser->setTextColor(Qt::blue);
        ui->textBrowser->append(file_on_kasumi);
        ui->textBrowser->setTextColor(Qt::black);
        ui->textEdit_kasumi->setText(fileInfo.fileName());

    //  FILE * in_file;
     // unsigned int in_read;
     // in_file_sobel = fopen(file_on, "rt");
     // while(fscanf(in_file,"%u", &in_read) != EOF){
       //  qDebug()<<"in:"<<in_read<<"\n";
    // }

    }

   }
   else{
       ui->textBrowser->setTextColor(Qt::red);
       ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
       ui->textBrowser->setTextColor(Qt::black);

   }
}

void MainWindow::on_pushButton_md5c_clicked()
{
ui->textBrowser->setTextColor(Qt::black);
    index=ui->comboBox->currentText();

   if(index.compare("Select File...")==0) {//open file
    QString openPath;
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                      openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

    QByteArray ba=filePath.toLatin1();
    file_on_md5c=ba.data();
   // qDebug()<<file_on<<"\n";

    if (!(filePath.isEmpty())){
        ui->checkBox_md5c->setChecked(true);
        QFile *file=new QFile;
        file->setFileName(filePath);
        QFileInfo fileInfo(*file);
        ui->textBrowser->append("Choosing File From: ");
        ui->textBrowser->setTextColor(Qt::blue);
        ui->textBrowser->append(file_on_md5c);
        ui->textBrowser->setTextColor(Qt::black);
        ui->textEdit_md5c->setText(fileInfo.fileName());

    //  FILE * in_file;
     // unsigned int in_read;
     // in_file_sobel = fopen(file_on, "rt");
     // while(fscanf(in_file,"%u", &in_read) != EOF){
       //  qDebug()<<"in:"<<in_read<<"\n";
    // }

    }

   }
   else{
       ui->textBrowser->setTextColor(Qt::red);
       ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
       ui->textBrowser->setTextColor(Qt::black);

   }
}



void MainWindow::on_pushButton_adpcm_clicked()
{
    ui->textBrowser->setTextColor(Qt::black);
        index=ui->comboBox->currentText();

       if(index.compare("Select File...")==0) {//open file
        QString openPath;
        QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                          openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

        QByteArray ba=filePath.toLatin1();
        file_on_adpcm=ba.data();
       // qDebug()<<file_on<<"\n";

        if (!(filePath.isEmpty())){
            ui->checkBox_adpcm->setChecked(true);
            QFile *file=new QFile;
            file->setFileName(filePath);
            QFileInfo fileInfo(*file);
            ui->textBrowser->append("Choosing File From: ");
            ui->textBrowser->setTextColor(Qt::blue);
            ui->textBrowser->append(file_on_adpcm);
            ui->textBrowser->setTextColor(Qt::black);
            ui->textEdit_adpcm->setText(fileInfo.fileName());

        //  FILE * in_file;
         // unsigned int in_read;
         // in_file_sobel = fopen(file_on, "rt");
         // while(fscanf(in_file,"%u", &in_read) != EOF){
           //  qDebug()<<"in:"<<in_read<<"\n";
        // }

        }

       }
       else{
           ui->textBrowser->setTextColor(Qt::red);
           ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
           ui->textBrowser->setTextColor(Qt::black);

       }
}

void MainWindow::on_pushButton_interp_clicked()
{
    ui->textBrowser->setTextColor(Qt::black);
        index=ui->comboBox->currentText();

       if(index.compare("Select File...")==0) {//open file
        QString openPath;
        QString filePath = QFileDialog::getOpenFileName(this, tr("Open File..."),
                                                          openPath, tr("TXT File(*.txt);;BMP File(*.bmp)"));

        QByteArray ba=filePath.toLatin1();
        file_on_interp=ba.data();
       // qDebug()<<file_on<<"\n";

        if (!(filePath.isEmpty())){
            ui->checkBox_interp->setChecked(true);
            QFile *file=new QFile;
            file->setFileName(filePath);
            QFileInfo fileInfo(*file);
            ui->textBrowser->append("Choosing File From: ");
            ui->textBrowser->setTextColor(Qt::blue);
            ui->textBrowser->append(file_on_interp);
            ui->textBrowser->setTextColor(Qt::black);
            ui->textEdit_interp->setText(fileInfo.fileName());

        //  FILE * in_file;
         // unsigned int in_read;
         // in_file_sobel = fopen(file_on, "rt");
         // while(fscanf(in_file,"%u", &in_read) != EOF){
           //  qDebug()<<"in:"<<in_read<<"\n";
        // }

        }

       }
       else{
           ui->textBrowser->setTextColor(Qt::red);
           ui->textBrowser->append("ERROR : To enable this function, Please select the input from << Select File... >>\n");
           ui->textBrowser->setTextColor(Qt::black);

       }
}

/*void MainWindow::on_comboBox_currentTextChanged(const QString &arg1)
{

    if((arg1.compare("Default File")==0 )){

        ui->textEdit_sobel->clear();
        ui->textEdit_fir->clear();
        ui->textEdit_qsort->clear();
        ui->textEdit_aes->clear();
        ui->textEdit_aesde->clear();
        ui->textEdit_snow3g->clear();
        ui->textEdit_kasumi->clear();
        ui->textEdit_md5c->clear();
        ui->textEdit_adpcm->clear();
        ui->textEdit_interp->clear();

        ui->textEdit_sobel->setText("lena512.bmp");
        ui->textEdit_fir->setText( "fir_in_data.txt");
        ui->textEdit_qsort->setText("qsort_in_data.txt");
        ui->textEdit_aes->setText("aes_cipher_input.txt");
        ui->textEdit_aesde->setText("aes_decipher_input.txt");
        ui->textEdit_kasumi->setText("snow_3G_input.txt" );
        ui->textEdit_md5c->setText(  "kasumi_indata.txt");
        ui->textEdit_snow3g->setText("md5c_input.txt");
        ui->textEdit_adpcm->setText("adpcm_input.txt" );
        ui->textEdit_interp->setText( "interp_in_data.txt" );
    }
    else if((arg1.compare("Random")==0 )){

        ui->textEdit_sobel->clear();
        ui->textEdit_fir->clear();
        ui->textEdit_qsort->clear();
        ui->textEdit_aes->clear();
        ui->textEdit_aesde->clear();
        ui->textEdit_snow3g->clear();
        ui->textEdit_kasumi->clear();
        ui->textEdit_md5c->clear();
        ui->textEdit_adpcm->clear();
        ui->textEdit_interp->clear();

    }
}*/

void MainWindow::on_comboBox_activated(const QString &arg1)
{

     index=ui->comboBox->currentText();
    if((index.compare("Default File")==0 )){

        ui->textEdit_sobel->clear();
        ui->textEdit_fir->clear();
        ui->textEdit_qsort->clear();
        ui->textEdit_aes->clear();
        ui->textEdit_aesde->clear();
        ui->textEdit_snow3g->clear();
        ui->textEdit_kasumi->clear();
        ui->textEdit_md5c->clear();
        ui->textEdit_adpcm->clear();
        ui->textEdit_interp->clear();

        ui->textEdit_sobel->setText("lena512.bmp");
        ui->textEdit_fir->setText( "fir_in_data.txt");
        ui->textEdit_qsort->setText("qsort_in_data.txt");
        ui->textEdit_aes->setText("aes_cipher_input.txt");
        ui->textEdit_aesde->setText("aes_decipher_input.txt");
        ui->textEdit_kasumi->setText("snow_3G_input.txt" );
        ui->textEdit_md5c->setText(  "kasumi_indata.txt");
        ui->textEdit_snow3g->setText("md5c_input.txt");
        ui->textEdit_adpcm->setText("adpcm_input.txt" );
        ui->textEdit_interp->setText( "interp_in_data.txt" );
    }
    else if((index.compare("Random")==0 )){

        ui->textEdit_sobel->clear();
        ui->textEdit_fir->clear();
        ui->textEdit_qsort->clear();
        ui->textEdit_aes->clear();
        ui->textEdit_aesde->clear();
        ui->textEdit_snow3g->clear();
        ui->textEdit_kasumi->clear();
        ui->textEdit_md5c->clear();
        ui->textEdit_adpcm->clear();
        ui->textEdit_interp->clear();

    }
}
