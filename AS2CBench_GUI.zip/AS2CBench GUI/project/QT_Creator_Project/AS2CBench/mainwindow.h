#ifndef MAINWINDOW_H
#define MAINWINDOW_H
//#include <QDialog>
#include <QMainWindow>
#include <QString>
#include <QLabel>
#include <QLineEdit>
#include <QProgressBar>
#include <QComboBox>
#include <QPushButton>
#include <QGridLayout>
#include <QProgressDialog>
#include <QFont>
#include <QCheckBox>
#include <QFileDialog>

#include <strings.h>
#include <string.h>
#include <iostream>
#include <QFileInfo>

#define sobel_func  ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" Sobel filter Function.");\
                    ui->textBrowser_info->append(" ALMs: 131/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 1005");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

#define fir_func    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" FIR filter Function.");\
                    ui->textBrowser_info->append(" ALMs: 104/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 1006");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

#define qsort_func  ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" Qsort Algorithm.");\
                    ui->textBrowser_info->append(" ALMs: 131/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 1005");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

#define aes_func    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" AES Cipher .");\
                    ui->textBrowser_info->append(" ALMs: 2010/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 1436");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

#define aesde_func  ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" AES Decipher.");\
                    ui->textBrowser_info->append(" ALMs: 3640/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 21909");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

#define snow3g_func ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" snow3g function.");\
                    ui->textBrowser_info->append(" ALMs: 317/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 2820");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

#define kasumi_func ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" Kasumi function.");\
                    ui->textBrowser_info->append(" ALMs: 633/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 3260");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

#define md5c_func   ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" MD5C Function.");\
                    ui->textBrowser_info->append(" ALMs: 4692/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 21015");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

#define adpcm_func   ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" ADPCM Function.");\
                    ui->textBrowser_info->append(" ALMs: 204/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 1436");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

#define interp_func   ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");\
                    ui->textBrowser_info->append(" Interp Function.");\
                    ui->textBrowser_info->append(" ALMs: 1140/28040");\
                    ui->textBrowser_info->append(" HW Code Lines: 1562");\
                    ui->textBrowser_info->append("~~~~~~~~~~~~~~~~~~");

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    bool check_all[8];

    uint8_t  * h2p_lw_UUT_addr;
    uint8_t   * h2p_lw_outvalid_addr;

    int w[60];
    unsigned int init[16];
    unsigned int key[32];
    unsigned int  input_key[16];
    int wrk;

    FILE * as2cbench;
    char * file_on_sobel;
    char * file_on_fir;
    char * file_on_qsort;
    char * file_on_aes;
    char * file_on_aesde;
    char * file_on_kasumi;
    char * file_on_snow3g;
    char * file_on_md5c;
    char * file_on_adpcm;
    char * file_on_interp;

  //  QString filePath_sobel;
  //  QString filePath_fir;
   // QString filePath_qsort;
  //  QString filePath_aes;
  //  QString filePath_aesde;
  //  QString filePath_kasumi;
  //  QString filePath_snow3g;
//    QString filePath_md5c;

    int invSbox[256]={
    0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb,
    0x7c,0xe3,0x39,0x82,0x9b,0x2f,0xff,0x87,0x34,0x8e,0x43,0x44,0xc4,0xde,0xe9,0xcb,
    0x54,0x7b,0x94,0x32,0xa6,0xc2,0x23,0x3d,0xee,0x4c,0x95,0x0b,0x42,0xfa,0xc3,0x4e,
    0x08,0x2e,0xa1,0x66,0x28,0xd9,0x24,0xb2,0x76,0x5b,0xa2,0x49,0x6d,0x8b,0xd1,0x25,
    0x72,0xf8,0xf6,0x64,0x86,0x68,0x98,0x16,0xd4,0xa4,0x5c,0xcc,0x5d,0x65,0xb6,0x92,
    0x6c,0x70,0x48,0x50,0xfd,0xed,0xb9,0xda,0x5e,0x15,0x46,0x57,0xa7,0x8d,0x9d,0x84,
    0x90,0xd8,0xab,0x00,0x8c,0xbc,0xd3,0x0a,0xf7,0xe4,0x58,0x05,0xb8,0xb3,0x45,0x06,
    0xd0,0x2c,0x1e,0x8f,0xca,0x3f,0x0f,0x02,0xc1,0xaf,0xbd,0x03,0x01,0x13,0x8a,0x6b,
    0x3a,0x91,0x11,0x41,0x4f,0x67,0xdc,0xea,0x97,0xf2,0xcf,0xce,0xf0,0xb4,0xe6,0x73,
    0x96,0xac,0x74,0x22,0xe7,0xad,0x35,0x85,0xe2,0xf9,0x37,0xe8,0x1c,0x75,0xdf,0x6e,
    0x47,0xf1,0x1a,0x71,0x1d,0x29,0xc5,0x89,0x6f,0xb7,0x62,0x0e,0xaa,0x18,0xbe,0x1b,
    0xfc,0x56,0x3e,0x4b,0xc6,0xd2,0x79,0x20,0x9a,0xdb,0xc0,0xfe,0x78,0xcd,0x5a,0xf4,
    0x1f,0xdd,0xa8,0x33,0x88,0x07,0xc7,0x31,0xb1,0x12,0x10,0x59,0x27,0x80,0xec,0x5f,
    0x60,0x51,0x7f,0xa9,0x19,0xb5,0x4a,0x0d,0x2d,0xe5,0x7a,0x9f,0x93,0xc9,0x9c,0xef,
    0xa0,0xe0,0x3b,0x4d,0xae,0x2a,0xf5,0xb0,0xc8,0xeb,0xbb,0x3c,0x83,0x53,0x99,0x61,
    0x17,0x2b,0x04,0x7e,0xba,0x77,0xd6,0x26,0xe1,0x69,0x14,0x63,0x55,0x21,0x0c,0x7d
  };
    int Sbox[256] = {
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
  };
    QString index;

    unsigned long index_val;


    //delay
    void delay_s(int seconds);


    //sobel
    void sobel_send(bool hwsw);
    unsigned int sobel_filter(unsigned int *input_row_r);
    unsigned char * load_bitmapfile(const char *image);
    void sobel_compare_results(bool hwsw);
    void sobel_image_write(void);
    void sobel_main(bool hwsw,bool single_double);

    //fir
    unsigned int fir_filter( unsigned int  *ary, unsigned int  *coeff);
    void  fir_compare_results(bool hwsw);
    void  fir_send(bool hwsw);
    void  fir_main(bool hwsw,bool single_double) ;

    //qsort
    void sort(unsigned int *arr);
    void swap(int *end, int *beg);
    void qsort_compare_results(bool hwsw);
    void qsort_send(bool hwsw);
    void qsort_main(bool hwsw,bool single_double) ;

    //aes cipher
    void aes_AddRoundKey(int *,int);
    int  aes_Computing(int *, int*);
    int  aes_dataget(int *,int);
    void aes_KeyExpansion(unsigned int *, const  int*);
    void aes_MixColumns(int *);
    int  aes_mul(int,int);
    void aes_ShiftRows(int *);
    void aes_SubBytes(int *, const int*);
    int  aes_SubWord(int, const int*);
    int  aes_RotWord(int);
    void aes_compare_results(bool hwsw);
    void aes_send(bool hwsw);
    void aes_main(bool hwsw,bool single_double) ;

    //aes decipher
    void aes_de_AddRoundKey(int *,int);
    int  aes_de_Computing(int *, int*);
    int  aes_de_dataget(int *,int);
    void aes_de_KeyExpansion(unsigned int *, const  int*);
    void aes_de_MixColumns(int *);
    int  aes_de_mul(int,int);
    void aes_de_ShiftRows(int *);
    void aes_de_SubBytes(int *, const int*);
    int  aes_de_SubWord(int, const int*);
    int  aes_de_RotWord(int);
    void aes_de_compare_results(bool hwsw);
    void aes_de_send(bool hwsw);
    void aes_de_main(bool hwsw,bool single_double) ;

    //snow3g
    typedef unsigned char u8;
    typedef unsigned short u16;
    typedef unsigned long u32;
    typedef unsigned long long u64;
    void  Initialize(u32 k[4], u32 IV[4]);
    void  ClockLFSRKeyStreamMode();
    u32   ClockFSM();
    void  ClockLFSRInitializationMode(u32 F);
    u32  S2(u32 w);
    u32 S1(u32 w);
    u32  DIValpha(u8 c);
    u32 MULalpha(u8 c);
    u8  MULxPOW(u8 V, u8 i,  u8 c);
    u8 MULx(u8 V, u8 c);
    void snow3g_compare_results(bool hwsw);
    void snow3g_send(bool hwsw);
    void snow3g_main(bool hwsw,bool single_double) ;

    //kasumi
    u32  FL( u32 in_data, int index );
    u32  FO( u32 in_data, int index );
    u16  FI( u16 in_data, u16 subkey );
    void kasumi_compare_results(bool hwsw);
    void kasumi_send(bool hwsw);
    void kasumi_main(bool hwsw,bool single_double) ;

    //md5c
    void entry();
    void MD5Init();
    void MD5Update();
    void MD5Final();
    void MD5Pad();
    void MD5Transform();
    void md5c_compare_results(bool hwsw);
    void md5c_send(bool hwsw);
    void md5c_main(bool hwsw,bool single_double) ;


    //adpcm
    void adpcm_compare_results(bool hwsw);
    void adpcm_send(bool hwsw);
    void adpcm_main(bool hwsw,bool single_double) ;
    unsigned int adpcm_div_mod(unsigned int numerator, unsigned int denominator );
    unsigned int adpcm_get_index_delta( unsigned int enc );

    //interp
    void interp_compare_results(bool hwsw);
    void interp_send(bool hwsw);
    void interp_main(bool hwsw,bool single_double) ;

private slots:


    void on_checkBox_all_clicked();

    void on_pushButton_clicked();



    void on_checkBox_sobel_toggled(bool checked);

    void on_checkBox_fir_toggled(bool checked);

    void on_checkBox_qsort_toggled(bool checked);

    void on_checkBox_aes_toggled(bool checked);

    void on_checkBox_aesde_toggled(bool checked);

    void on_checkBox_snow3g_toggled(bool checked);

    void on_checkBox_kasumi_toggled(bool checked);

    void on_checkBox_md5c_toggled(bool checked);

    void on_textBrowser_textChanged();


    void on_pushButton_sobel_clicked();

    void on_pushButton_fir_clicked();

    void on_pushButton_qsort_clicked();

    void on_pushButton_aes_clicked();

    void on_pushButton_aesde_clicked();

    void on_pushButton_snow3g_clicked();

    void on_pushButton_kasumi_clicked();

    void on_pushButton_md5c_clicked();

    void on_checkBox_adpcm_toggled(bool checked);

    void on_checkBox_interp_toggled(bool checked);

    void on_pushButton_adpcm_clicked();

    void on_pushButton_interp_clicked();

   // void on_comboBox_currentTextChanged(const QString &arg1);

    void on_comboBox_activated(const QString &arg1);

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
