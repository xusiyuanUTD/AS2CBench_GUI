
#include "define.h"

  unsigned int digest[4];

  //For data feeding
  FILE * md5c_in_file, *md5c_out_file_golden, *md5c_out_file, *md5c_diff_file;

  // Member variables declaration
  unsigned int		m_inputLen;
  unsigned int		m_input[ MD5C_INPUT_BUFSIZE ];

  unsigned int	m_state[4];	/* state (ABCD) */
  unsigned int	m_count[2];	/* number of bits, modulo 2^64 (lsb first) */
  unsigned int	m_buffer[64];	/* input buffer */

static const unsigned char PADDING[64] = {
  0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/* F, G, H and I are basic MD5 functions. */
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define I(x, y, z) ((y) ^ ((x) | (~z)))

/* ROTATE_LEFT rotates x left n bits. */
#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))

/*
 * FF, GG, HH, and II transformations for rounds 1, 2, 3, and 4.
 * Rotation is separate from addition to prevent recomputation.
 */
#define FF(a, b, c, d, x, s, ac) { \
    (a) += F ((b), (c), (d)) + (x) + (u_int32_t)(ac); \
    (a) = ROTATE_LEFT ((a), (s)); \
    (a) += (b); \
    }
#define GG(a, b, c, d, x, s, ac) { \
    (a) += G ((b), (c), (d)) + (x) + (u_int32_t)(ac); \
    (a) = ROTATE_LEFT ((a), (s)); \
    (a) += (b); \
    }
#define HH(a, b, c, d, x, s, ac) { \
    (a) += H ((b), (c), (d)) + (x) + (u_int32_t)(ac); \
    (a) = ROTATE_LEFT ((a), (s)); \
    (a) += (b); \
    }
#define II(a, b, c, d, x, s, ac) { \
    (a) += I ((b), (c), (d)) + (x) + (u_int32_t)(ac); \
    (a) = ROTATE_LEFT ((a), (s)); \
    (a) += (b); \
    }

/* MD5 initialization. Begins an MD5 operation, writing a new context. */

void MainWindow::MD5Init()
{


  m_count[0] = m_count[1] = 0;

  /* Load magic initialization constants.  */
  m_state[0] = 0x67452301;
  m_state[1] = 0xefcdab89;
  m_state[2] = 0x98badcfe;
  m_state[3] = 0x10325476;
}

/*
 * MD5 block update operation. Continues an MD5 message-digest
 * operation, processing another message block, and updating the
 * context.
 */

void MainWindow::MD5Update()
{

  unsigned int inputLen = m_inputLen;
  unsigned int j;

  /* Compute number of bytes mod 64 */
  unsigned int idx = ((m_count[0] >> 3) & 0x3F);

  /* Update number of bits */
  if ((m_count[0] += ((u_int32_t)inputLen << 3))
      < ((u_int32_t)inputLen << 3)) {
    m_count[1]++;
  }
  m_count[1] += ((u_int32_t)inputLen >> 29);

  unsigned int partLen = 64 - idx;

  /* Transform as many times as possible. */
  unsigned int i;
  if ( inputLen >= partLen ) {

    for ( j = 0; j < partLen; j++ ) m_buffer[idx+j] = m_input[j];
    MD5Transform();

    for (i = partLen; i + 63 < inputLen; i += 64) {

      for ( j = 0; j < 64; j++ ) m_buffer[j] = m_input[i+j];
      MD5Transform();
    }
    idx = 0;

  } else {
    i = 0;
  }

  /* Buffer remaining input */

  for (  j = 0; j < inputLen-i; j ++ ) m_buffer[idx+j] = m_input[i+j];
}

/*
 * MD5 padding. Adds padding followed by original length.
 */

void MainWindow::MD5Pad()
{
  unsigned int j;

  /* Save number of bits */
  unsigned int bits[8];
 // ( bits[3], bits[2], bits[1], bits[0] ) = m_count[0];
 // ( bits[7], bits[6], bits[5], bits[4] ) = m_count[1];

  bits[3]=m_count[0];
  bits[2]=m_count[0];
  bits[1]=m_count[0];
  bits[0]=m_count[0];
  bits[7]=m_count[1];
  bits[6]=m_count[1];
  bits[5]=m_count[1];
  bits[4]=m_count[1];

  /* Pad out to 56 mod 64. */
  unsigned int idx = (m_count[0] >> 3) & 0x3f;
  unsigned int padLen = (idx < 56) ? (56 - idx) : (120 - idx);

  for ( j = 0; j < padLen; j++ ) m_input[j] = PADDING[j];
  m_inputLen = padLen;
  MD5Update();

  /* Append length (before padding) */
  for ( j = 0; j < 8; j++ ) m_input[j] = bits[j];
  m_inputLen = 8;
  MD5Update();
}

/*
 * MD5 finalization. Ends an MD5 message-digest operation, writing the
 * the message digest and zeroizing the context.
 */

void MainWindow::MD5Final()
{
    int j;
  //char szText[64];
  /* Do padding. */
  MD5Pad();

  /* Store state in digest */
  for ( j = 0; j < 4; j ++ ) {

    digest[j]= m_state[j]& 0x000000ff;
    digest[j]=(m_state[j] &0x0000ff00)>>8;
    digest[j]=( m_state[j]&0x00ff0000) >>16;
    digest[j]=( m_state[j]&0xff000000)>>24;

  }
  for ( j = 0; j < 4; j ++ ) {
     if((index.compare("Default File")==0 )| (index.compare("Select File...")==0))
         fprintf(md5c_out_file,"%u ",digest[j]);

     //  else qDebug()<<digest[j]<<"\n";

   //sprintf(szText, "%u \r", digest[j]);
   //ui->textBrowser_md5cout->append(szText);
   //ui->progressBar_md5c->setValue(j);
   //   ui->progressBar->setValue(j);
  }
  if((index.compare("Default File")==0 )| (index.compare("Select File...")==0))  fprintf(md5c_out_file,"\n");



}

/* MD5 basic transformation. Transforms state based on block. */

void MainWindow::MD5Transform ()
{
  int j;
  u_int32_t a = m_state[0], b = m_state[1], c = m_state[2], d = m_state[3];
  u_int32_t x[16];
  for (  j = 0; j < 16; j ++ ) {
    unsigned int b0 = m_buffer[4*j+0];
    //unsigned int b1 = m_buffer[4*j+1];
    //unsigned int b2 = m_buffer[4*j+2];
    //unsigned int b3 = m_buffer[4*j+3];
    //x[ j ] = ( b3, b2, b1, b0 );
    x[ j ] = b0 ;

  }

  /* Round 1 */
#define S11 7
#define S12 12
#define S13 17
#define S14 22
  FF (a, b, c, d, x[ 0], S11, 0xd76aa478); /* 1 */
  FF (d, a, b, c, x[ 1], S12, 0xe8c7b756); /* 2 */
  FF (c, d, a, b, x[ 2], S13, 0x242070db); /* 3 */
  FF (b, c, d, a, x[ 3], S14, 0xc1bdceee); /* 4 */
  FF (a, b, c, d, x[ 4], S11, 0xf57c0faf); /* 5 */
  FF (d, a, b, c, x[ 5], S12, 0x4787c62a); /* 6 */
  FF (c, d, a, b, x[ 6], S13, 0xa8304613); /* 7 */
  FF (b, c, d, a, x[ 7], S14, 0xfd469501); /* 8 */
  FF (a, b, c, d, x[ 8], S11, 0x698098d8); /* 9 */
  FF (d, a, b, c, x[ 9], S12, 0x8b44f7af); /* 10 */
  FF (c, d, a, b, x[10], S13, 0xffff5bb1); /* 11 */
  FF (b, c, d, a, x[11], S14, 0x895cd7be); /* 12 */
  FF (a, b, c, d, x[12], S11, 0x6b901122); /* 13 */
  FF (d, a, b, c, x[13], S12, 0xfd987193); /* 14 */
  FF (c, d, a, b, x[14], S13, 0xa679438e); /* 15 */
  FF (b, c, d, a, x[15], S14, 0x49b40821); /* 16 */

  /* Round 2 */
#define S21 5
#define S22 9
#define S23 14
#define S24 20
  GG (a, b, c, d, x[ 1], S21, 0xf61e2562); /* 17 */
  GG (d, a, b, c, x[ 6], S22, 0xc040b340); /* 18 */
  GG (c, d, a, b, x[11], S23, 0x265e5a51); /* 19 */
  GG (b, c, d, a, x[ 0], S24, 0xe9b6c7aa); /* 20 */
  GG (a, b, c, d, x[ 5], S21, 0xd62f105d); /* 21 */
  GG (d, a, b, c, x[10], S22,  0x2441453); /* 22 */
  GG (c, d, a, b, x[15], S23, 0xd8a1e681); /* 23 */
  GG (b, c, d, a, x[ 4], S24, 0xe7d3fbc8); /* 24 */
  GG (a, b, c, d, x[ 9], S21, 0x21e1cde6); /* 25 */
  GG (d, a, b, c, x[14], S22, 0xc33707d6); /* 26 */
  GG (c, d, a, b, x[ 3], S23, 0xf4d50d87); /* 27 */
  GG (b, c, d, a, x[ 8], S24, 0x455a14ed); /* 28 */
  GG (a, b, c, d, x[13], S21, 0xa9e3e905); /* 29 */
  GG (d, a, b, c, x[ 2], S22, 0xfcefa3f8); /* 30 */
  GG (c, d, a, b, x[ 7], S23, 0x676f02d9); /* 31 */
  GG (b, c, d, a, x[12], S24, 0x8d2a4c8a); /* 32 */

  /* Round 3 */
#define S31 4
#define S32 11
#define S33 16
#define S34 23
  HH (a, b, c, d, x[ 5], S31, 0xfffa3942); /* 33 */
  HH (d, a, b, c, x[ 8], S32, 0x8771f681); /* 34 */
  HH (c, d, a, b, x[11], S33, 0x6d9d6122); /* 35 */
  HH (b, c, d, a, x[14], S34, 0xfde5380c); /* 36 */
  HH (a, b, c, d, x[ 1], S31, 0xa4beea44); /* 37 */
  HH (d, a, b, c, x[ 4], S32, 0x4bdecfa9); /* 38 */
  HH (c, d, a, b, x[ 7], S33, 0xf6bb4b60); /* 39 */
  HH (b, c, d, a, x[10], S34, 0xbebfbc70); /* 40 */
  HH (a, b, c, d, x[13], S31, 0x289b7ec6); /* 41 */
  HH (d, a, b, c, x[ 0], S32, 0xeaa127fa); /* 42 */
  HH (c, d, a, b, x[ 3], S33, 0xd4ef3085); /* 43 */
  HH (b, c, d, a, x[ 6], S34,  0x4881d05); /* 44 */
  HH (a, b, c, d, x[ 9], S31, 0xd9d4d039); /* 45 */
  HH (d, a, b, c, x[12], S32, 0xe6db99e5); /* 46 */
  HH (c, d, a, b, x[15], S33, 0x1fa27cf8); /* 47 */
  HH (b, c, d, a, x[ 2], S34, 0xc4ac5665); /* 48 */

  /* Round 4 */
#define S41 6
#define S42 10
#define S43 15
#define S44 21
  II (a, b, c, d, x[ 0], S41, 0xf4292244); /* 49 */
  II (d, a, b, c, x[ 7], S42, 0x432aff97); /* 50 */
  II (c, d, a, b, x[14], S43, 0xab9423a7); /* 51 */
  II (b, c, d, a, x[ 5], S44, 0xfc93a039); /* 52 */
  II (a, b, c, d, x[12], S41, 0x655b59c3); /* 53 */
  II (d, a, b, c, x[ 3], S42, 0x8f0ccc92); /* 54 */
  II (c, d, a, b, x[10], S43, 0xffeff47d); /* 55 */
  II (b, c, d, a, x[ 1], S44, 0x85845dd1); /* 56 */
  II (a, b, c, d, x[ 8], S41, 0x6fa87e4f); /* 57 */
  II (d, a, b, c, x[15], S42, 0xfe2ce6e0); /* 58 */
  II (c, d, a, b, x[ 6], S43, 0xa3014314); /* 59 */
  II (b, c, d, a, x[13], S44, 0x4e0811a1); /* 60 */
  II (a, b, c, d, x[ 4], S41, 0xf7537e82); /* 61 */
  II (d, a, b, c, x[11], S42, 0xbd3af235); /* 62 */
  II (c, d, a, b, x[ 2], S43, 0x2ad7d2bb); /* 63 */
  II (b, c, d, a, x[ 9], S44, 0xeb86d391); /* 64 */

  m_state[0] += a;
  m_state[1] += b;
  m_state[2] += c;
  m_state[3] += d;
}





//------------------------
// Compare results function
//------------------------
void MainWindow::md5c_compare_results(bool hwsw){

  unsigned int outdigest, outdigest_golden;
  int  line=1, errors=0;
 char szText[64];
  // Close file where outputs are stored
 // fclose(md5c_out_file);

  if(hwsw)
  md5c_out_file = fopen (MD5C_OUTFILENAMEHWSW, "rt");
  else
   md5c_out_file = fopen (MD5C_OUTFILENAMESW, "rt");

  if(!md5c_out_file){
      printf("Could not open MD5C_OUTFILENAME \n" );
    exit(EXIT_FAILURE);
  }



  //
  //Load the golden pattern
  //
  if(hwsw)
  md5c_out_file_golden = fopen (MD5C_OUTFILENAME_GOLDENHWSW, "rt");
  else
     md5c_out_file_golden = fopen (MD5C_OUTFILENAME_GOLDENSW, "rt");

  if(!md5c_out_file_golden){
      printf( "Could not open  MD5C_OUTFILENAME_GOLDEN \n" );

    exit(EXIT_FAILURE);
  }


    //
    //Dump the comparison result
    //
  if(hwsw)
    md5c_diff_file = fopen (MD5C_DIFFFILENAMEHWSW, "w");
  else
        md5c_diff_file = fopen (MD5C_DIFFFILENAMESW, "w");

    if(!md5c_diff_file){
      printf( "Could not open  MD5C_DIFFFILENAME \n" );
       }

    while(fscanf(md5c_out_file_golden, "%u", &outdigest_golden) != EOF){


      if(fscanf(md5c_out_file,"%u", &outdigest) == EOF)
    break;



      if(outdigest != outdigest_golden){
    fprintf(md5c_diff_file,"\nOutput missmatch[line:%d] Golden: %u -- Output: %u",line, outdigest_golden, outdigest);

    if(hwsw)sprintf(szText,"md5c(ARM+FPGA)::Output missmatch[line:%d] Golden: %u -- Output: %u",line, outdigest_golden, outdigest);
    else sprintf(szText,"md5c(ARM)::Output missmatch[line:%d] Golden: %u -- Output: %u",line, outdigest_golden, outdigest);
    ui->textBrowser->append(szText);
    errors++;
      }

      line ++;

    }

    if(errors == 0){
       if(hwsw)  ui->textBrowser->append("Finished md5c ARM+FPGA simulation SUCCESSFULLY !! " );
       else  ui->textBrowser->append("Finished md5c Pure ARM simulation SUCCESSFULLY !! " );
    }

    else{

        if(hwsw) sprintf(szText, "md5c(ARM+FPGA)::MISMATCH :: %u out of %u ",errors,line);
        else sprintf(szText, "md5c(ARM)::MISMATCH :: %u out of %u ",errors,line);
        ui->textBrowser->append(szText);
\


    }



    fclose(md5c_out_file);
    fclose(md5c_diff_file);
    fclose(md5c_out_file_golden);



}


//------------------------
// Send data thread
//----------------------
void MainWindow::md5c_send(bool hwsw){

  // Variables declaration
  int read;
  int j;
//  bool p=true;
  char szText[64];
  unsigned int inputlen;

   if( (index.compare("Default File")==0 )| (index.compare("Select File...")==0) ) {//open file
    ui->progressBar->setRange(0,3);
  if(hwsw) md5c_out_file = fopen (MD5C_OUTFILENAMEHWSW, "wt");
  else    md5c_out_file = fopen (MD5C_OUTFILENAMESW, "wt");

  if(!md5c_out_file){
   printf("Could not open  MD5C_OUTFILENAME \n" );
    exit (-1);
  }


  //Reset routine

 // md5c_in_file = fopen(MD5C_INFILENAME, "rt");
  if(index.compare("Default File")==0 ){   md5c_in_file = fopen(MD5C_INFILENAME, "rt");}
  else if(index.compare("Select File...")==0){md5c_in_file  = fopen(ui->textEdit_md5c->toPlainText().toLatin1().data(), "rt");}


  if(!md5c_in_file){
    printf("Could not open  MD5C_INFILENAME \n" );
    exit(EXIT_FAILURE);
  }


  bool final=true;
  MD5Init();  // Reset state



    while(fscanf(md5c_in_file,"%u", &inputlen) != EOF){



if(hwsw){

    alt_write_word(h2p_lw_UUT_addr,inputlen);
    //sprintf(szText, "%u \r", inputlen);
    //ui->textBrowser_md5cin->append(szText);

        //printf( "inputlen is  %u \n",inputlen );

          // Wait until the output has been completely writting out before
          // feeding new data

        while(1)	{
                 read=alt_read_word(h2p_lw_outvalid_addr);
                // printf( "valid %d \n",read );

                if(read)
                {
                // printf( "valid is %d \n",read );

                for(j=0;j<4;j++){
                alt_write_word(h2p_lw_outvalid_addr,true);
                digest[j] = alt_read_word(h2p_lw_UUT_addr);
                //printf( "output is  %u \n",digest );
                 fprintf(md5c_out_file,"%u ",digest[j]);
                // sprintf(szText, "%u \r", digest[j]);
                 //ui->textBrowser_md5cout->append(szText);
                 //  ui->progressBar->setValue(j);
                    }
                fprintf(md5c_out_file,"\n");

                 break;

                }

                }


}


else{
    m_inputLen=inputlen;
    sprintf(szText, "%u \r", inputlen);
    //ui->textBrowser_md5cin->append(szText);

   // assert( m_inputLen <= MD5C_INPUT_BUFSIZE );

    if( final == true ) {
      MD5Final();
    }
    else {
      MD5Update();
    }

}
    //printf( "inputlen is  %u \n",inputlen );

      // Wait until the output has been completely writting out before
      // feeding new data




    }


 ui->progressBar->setValue(3);
    fclose(md5c_in_file);
    fclose(md5c_out_file);
 if(index.compare("Default File")==0 ){
    if(hwsw)  md5c_compare_results(true);
    else     md5c_compare_results(false);} }

     else if(index.compare("Random")==0) {//open file --- don't need to compare

     ui->progressBar->setRange(0,index_val-1);

       bool final=true;
       MD5Init();  // Reset state







            for(unsigned long index_xx=0;index_xx<index_val;index_xx++) {

                ui->progressBar->setValue(index_xx);

                 if(hwsw)  alt_write_word(h2p_lw_UUT_addr,rand()%255);
                 else inputlen = rand()%255;


       if(hwsw){

           //sprintf(szText, "%u \r", inputlen);
           //ui->textBrowser_md5cin->append(szText);

               //printf( "inputlen is  %u \n",inputlen );

                 // Wait until the output has been completely writting out before
                 // feeding new data

               while(1)	{
                        read=alt_read_word(h2p_lw_outvalid_addr);
                       // printf( "valid %d \n",read );

                       if(read)
                       {
                       // printf( "valid is %d \n",read );

                       for(j=0;j<4;j++){
                       alt_write_word(h2p_lw_outvalid_addr,true);
                       digest[j] = alt_read_word(h2p_lw_UUT_addr);
                       //printf( "output is  %u \n",digest );
                       // fprintf(md5c_out_file,"%u ",digest[j]);
                       // sprintf(szText, "%u \r", digest[j]);
                        //ui->textBrowser_md5cout->append(szText);
                        //  ui->progressBar->setValue(j);
                           }
                      // fprintf(md5c_out_file,"\n");

                        break;

                       }

                       }


       }


       else{
           m_inputLen=inputlen;
           //sprintf(szText, "%u \r", inputlen);
           //ui->textBrowser_md5cin->append(szText);

          // assert( m_inputLen <= MD5C_INPUT_BUFSIZE );

           if( final == true ) {
             MD5Final();
           }
           else {
             MD5Update();
           }

       }

            }


   }


}




//--------------------------
// Main function
//--------------------------
void  MainWindow::md5c_main(bool hwsw,bool single_double) //0:ARM 1:ARM+FPGA
{


    void *virtual_base;
    int fd;
    QPixmap pixmap;
    GET_TIME_INIT(3);
    char szText[64];
    double compare_t[2];
    double compare_bool;

        if(hwsw)  { //ARM+FPGA
    // map the address space for the LED registers into user space so we can interact with them.
    // we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
    if( ( fd = ::open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );

    }
    virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        ::close( fd );

    }
    h2p_lw_UUT_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_9_BASE) & ( unsigned long)( HW_REGS_MASK ) );
    h2p_lw_outvalid_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + VALID_OUT_9_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
    if(single_double){
        ui->textBrowser->append("Start the  md5c simulation...");
          fprintf(as2cbench,"Start the  md5c simulation...\n");

        GET_TIME_VAL(0);
        md5c_send(false);  //ARM
        GET_TIME_VAL(1);
        md5c_send(true);  //ARM+FPGA
        GET_TIME_VAL(2);

        compare_t[0]=(TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0;
        compare_t[1]=(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0;

        compare_bool=(compare_t[0]-compare_t[1])/compare_t[0];
        compare_bool=(compare_bool*100); //==> 100%
        ui->textBrowser->append("End of the  md5c Filter simulation..");
        ui->textBrowser->append("  ");
        ui->textBrowser->append("   md5c Simulation Results: ");
        ui->textBrowser->append(" -------------------------------------------- ");
        ui->textBrowser->append("   Pure ARM     ||     ARM+FPGA  : ");
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "MD5C Accelerated %0.2lf%%",compare_bool);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" ----------------------------------------------------------- ");

        fprintf(as2cbench,"End of the md5c simulation..\n");
        fprintf(as2cbench,"  \n");
        fprintf(as2cbench,"   md5c Simulation Results: \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        fprintf(as2cbench,"   Pure ARM     ||     ARM+FPGA  : \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "Accelerated %0.2lf%%\n",compare_bool);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," ----------------------------------------------------------- \n");
    }


    else{
        ui->textBrowser->append("Start the md5c ARM+FPGA simulation...");
          fprintf(as2cbench,"Start the  md5c ARM+FPGA simulation...\n");
    GET_TIME_VAL(0);
    md5c_send(true);  //ARM+FPGA
    GET_TIME_VAL(1);
    ui->textBrowser->append("End of the  md5c ARM+FPGA simulation..");
     fprintf(as2cbench,"End of the  md5c ARM+FPGA simulation..\n");

    sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
    ui->textBrowser->append(szText);
    fprintf(as2cbench,szText);

    }
    if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
        printf( "ERROR: munmap() failed...\n" );
        ::close( fd );

    }

    ::close( fd );  }


        else {
            ui->textBrowser->append("Start the  md5c ARM simulation...");
              fprintf(as2cbench,"Start the md5c ARM simulation...\n");
            GET_TIME_VAL(0);
            md5c_send(false);  //ARM
            GET_TIME_VAL(1);
            ui->textBrowser->append("End of the  md5c ARM simulation..");
             fprintf(as2cbench,"End of the  md5c ARM simulation..\n");

            sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
            ui->textBrowser->append(szText);
             fprintf(as2cbench,szText);

    }




}
