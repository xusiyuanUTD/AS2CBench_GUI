#include "define.h"


  //For data feeding
  FILE * qsort_in_file, *qsort_out_golden_file, *qsort_qsort_out_file_read;
  FILE  *qsort_out_file, *qsort_diff_file;

void MainWindow::swap(int *end, int *beg){

  int swap;

  swap=*beg;
  *beg=*(beg-1);
  *(beg-1)=swap;

  swap=*end;
  *end=*(end-1);
  *(end-1)=swap;


}

//--------------------------
// Main sorting function
//-------------------------
void MainWindow::sort(unsigned int *arr){


  // Variables declaration
  int  piv, beg[QSORT_SIZE], end[QSORT_SIZE], i=0, L, R;

  beg[0]=0;
  end[0]=QSORT_SIZE;

  while (i>=0) {

    L=beg[i]; R=end[i]-1;
    if (L<R) {
      piv=arr[L];

      while (L<R) {
        while (arr[R]>=piv && L<R)
      R--;
    if (L<R)
      arr[L++]=arr[R];

    while (arr[L]<=piv && L<R)
      L++;
    if(L<R)
      arr[R--]=arr[L];
      }

      arr[L]=piv;
      beg[i+1]=L+1;
      end[i+1]=end[i];
      end[i++]=L;

      if (end[i]-beg[i]>end[i-1]-beg[i-1]){
    swap(&end[i], &beg[i]);

      }
    }

    else{
      i--;
    }
  } // end while

}







//--------------------------
// Compare results function
//--------------------------
void MainWindow::qsort_compare_results(bool hwsw){

  int outsort, out_golden, line=1, errors=0;
 char szText[64];
  // Close file where outputs are stored
  //fclose(qsort_out_file);
  if (hwsw){
  qsort_out_file = fopen (QSORT_OUTFILENAMEHWSW, "rt");}
   else{
      qsort_out_file = fopen (QSORT_OUTFILENAMESW, "rt");}


  if(!qsort_out_file){
    exit(EXIT_FAILURE);
  }

    //
    //Load the golden pattern
    //
    if(hwsw){
      qsort_out_golden_file = fopen (QSORT_OUTFILENAME_GOLDENHWSW, "rt");}
    else {
        qsort_out_golden_file = fopen (QSORT_OUTFILENAME_GOLDENSW, "rt");}

     if(!qsort_out_golden_file){
      exit(EXIT_FAILURE);
     }

    //
    //Dump the comparison result
    //
     if(hwsw){
    qsort_diff_file = fopen (QSORT_DIFFFILENAMEHWSW, "w");}
     else{
         qsort_diff_file = fopen (QSORT_DIFFFILENAMESW, "w");}

    if(!qsort_diff_file){
       }

    while(fscanf(qsort_out_golden_file, "%d", &out_golden) != EOF){
      fscanf(qsort_out_file,"%d", &outsort);


      if(outsort != out_golden){

    fprintf(qsort_diff_file,"\nOutput missmatch[line:%d] Golden: %d -- Output: %d",line, out_golden, outsort);

    if(hwsw) sprintf(szText, "qsort(ARM+FPGA)::Output missmatch[line:%d] Golden: %d -- Output: %d",line, out_golden, outsort);
    else  sprintf(szText, "qsort(ARM+FPGA)::Output missmatch[line:%d] Golden: %d -- Output: %d",line, out_golden, outsort);
    ui->textBrowser->append(szText);
    errors++;
      }

      line ++;

    }

    if(errors == 0){
       if(hwsw)  ui->textBrowser->append("Finished qsort ARM+FPGA simulation SUCCESSFULLY !! " );
       else  ui->textBrowser->append("Finished qsort Pure ARM simulation SUCCESSFULLY !! " );
    }

    else{
       if(hwsw) sprintf(szText, "qsort(ARM+FPGA)::MISMATCH :: %u out of %u ",errors,line);
       else sprintf(szText, "qsort(ARM)::MISMATCH :: %u out of %u ",errors,line);
        ui->textBrowser->append(szText);



    }


    fclose(qsort_out_file);
    fclose(qsort_diff_file);
    fclose(qsort_out_golden_file);



}



//--------------------------
// Send data thread
//-------------------------
void MainWindow::qsort_send(bool hwsw){

  // Variables declaration
  int i=0,x;
  unsigned int in_read[QSORT_SIZE];

  // Variables declaration
  unsigned int out_write=0;
  int read;
  char szText[64];

   if( (index.compare("Default File")==0 )| (index.compare("Select File...")==0) ) {//open file
  ui->progressBar->setRange(0,QSORT_SIZE);

  if(index.compare("Default File")==0 ){ qsort_in_file = fopen(QSORT_INFILENAME, "rt");}
  else if(index.compare("Select File...")==0){qsort_in_file = fopen(ui->textEdit_qsort->toPlainText().toLatin1().data(), "rt");}

  //Reset routine



  if(!qsort_in_file){
    exit(EXIT_FAILURE);
  }
  if(hwsw){
  qsort_out_file = fopen (QSORT_OUTFILENAMEHWSW, "wt");}
  else{
      qsort_out_file = fopen (QSORT_OUTFILENAMESW, "wt");}

  if(!qsort_out_file){
  }

    while(fscanf(qsort_in_file,"%d", &in_read[i]) != EOF){

        if(hwsw) alt_write_word(h2p_lw_UUT_addr,in_read[i]);

        sprintf(szText, "%u \r", in_read[i]);
        //ui->textBrowserin->append(szText);


        i++;
       ui->progressBar->setValue(i);

      if(i==QSORT_SIZE)
                {
            i=0;
       if(hwsw){

            while(1){
             read=alt_read_word(h2p_lw_outvalid_addr);

            if(read)
            {
            for(x=0;x<QSORT_SIZE;x++){
             alt_write_word(h2p_lw_outvalid_addr,true);
             out_write = alt_read_word(h2p_lw_UUT_addr);
             fprintf(qsort_out_file,"%d\n",out_write);
             //printf("output is %d\n",filter_out_write);
             sprintf(szText, "%u \r", out_write);
             //ui->textBrowserout->append(szText);

                     }
             break;

            }
            }  }
       else{


      sort(in_read);

    for(x=0;x<QSORT_SIZE;x++){

             out_write = in_read[x];
             fprintf(qsort_out_file,"%d\n",out_write);
             sprintf(szText, "%u \r", out_write);
             //ui->textBrowserout->append(szText);

            }  }


            }


    }
 ui->progressBar->setValue(QSORT_SIZE);

    fclose(qsort_in_file);
    fclose(qsort_out_file);
if(index.compare("Default File")==0 ){
    if(hwsw) qsort_compare_results(true);
    else qsort_compare_results(false);

}


}


   else if(index.compare("Random")==0) {//open file --- don't need to compare



       ui->progressBar->setRange(0,index_val-1);

            for(unsigned long index_xx=0;index_xx<index_val;index_xx++) {

                ui->progressBar->setValue(index_xx);

                 for(int index_yy=0;index_yy<QSORT_SIZE;index_yy++){
                  if(hwsw)  alt_write_word(h2p_lw_UUT_addr,rand()%255);
                  else in_read[index_yy] = rand()%255;
              }

                 if(hwsw){

                      while(1){
                       read=alt_read_word(h2p_lw_outvalid_addr);

                      if(read)
                      {
                      for(x=0;x<QSORT_SIZE;x++){
                       alt_write_word(h2p_lw_outvalid_addr,true);
                       out_write = alt_read_word(h2p_lw_UUT_addr);
                       //fprintf(qsort_out_file,"%d\n",out_write);
                       //printf("output is %d\n",filter_out_write);
                       //sprintf(szText, "%u \r", out_write);
                       //ui->textBrowserout->append(szText);

                               }
                       break;

                      }
                      }  }
                 else{


                sort(in_read);

              for(x=0;x<QSORT_SIZE;x++){

                       out_write = in_read[x];
                      // fprintf(qsort_out_file,"%d\n",out_write);
                      // sprintf(szText, "%u \r", out_write);
                       //ui->textBrowserout->append(szText);

                       //  qDebug()<<"output is"<<out_write<<"\n";

                      }  }



            }

   }



}



//--------------------------
// Main function
//--------------------------

void  MainWindow::qsort_main(bool hwsw,bool single_double) //0:ARM 1:ARM+FPGA
{


    void *virtual_base;
    int fd;
    QPixmap pixmap;
    GET_TIME_INIT(3);
    char szText[64];
    double compare_t[2];
    double compare_bool;

        if(hwsw)  { //ARM+FPGA
    // map the address space for the LED registers into user space so we can interact with them.
    // we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
    if( ( fd = ::open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );

    }
    virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        ::close( fd );

    }
    h2p_lw_UUT_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_2_BASE) & ( unsigned long)( HW_REGS_MASK ) );
    h2p_lw_outvalid_addr=( uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + VALID_OUT_2_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
    if(single_double){
        ui->textBrowser->append("Start the  Qsort simulation...");
          fprintf(as2cbench,"Start the  Qsort simulation...\n");

        GET_TIME_VAL(0);
        qsort_send(false);  //ARM
        GET_TIME_VAL(1);
        qsort_send(true);  //ARM+FPGA
        GET_TIME_VAL(2);

        compare_t[0]=(TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0;
        compare_t[1]=(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0;

        compare_bool=(compare_t[0]-compare_t[1])/compare_t[0];
        compare_bool=(compare_bool*100); //==> 100%
        ui->textBrowser->append("End of the  qsort Filter simulation..");
        ui->textBrowser->append("  ");
        ui->textBrowser->append("   Qsort Simulation Results: ");
        ui->textBrowser->append(" -------------------------------------------- ");
        ui->textBrowser->append("   Pure ARM     ||     ARM+FPGA  : ");
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "Qsort Accelerated %0.2lf%%",compare_bool);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" ----------------------------------------------------------- ");

        fprintf(as2cbench,"End of the Qsort simulation..\n");
        fprintf(as2cbench,"  \n");
        fprintf(as2cbench,"   Qsort Simulation Results: \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        fprintf(as2cbench,"   Pure ARM     ||     ARM+FPGA  : \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "Accelerated %0.2lf%%\n",compare_bool);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," ----------------------------------------------------------- \n");
    }


    else{
        ui->textBrowser->append("Start the Qsort ARM+FPGA simulation...");
          fprintf(as2cbench,"Start the  Qsort ARM+FPGA simulation...\n");
    GET_TIME_VAL(0);
    qsort_send(true);  //ARM+FPGA
    GET_TIME_VAL(1);
    ui->textBrowser->append("End of the  Qsort ARM+FPGA simulation..");
     fprintf(as2cbench,"End of the  Qsort ARM+FPGA simulation..\n");

    sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
    ui->textBrowser->append(szText);
    fprintf(as2cbench,szText);

    }
    if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
        printf( "ERROR: munmap() failed...\n" );
        ::close( fd );

    }

    ::close( fd );  }


        else {
            ui->textBrowser->append("Start the  Qsort ARM simulation...");
              fprintf(as2cbench,"Start the Qsort ARM simulation...\n");
            GET_TIME_VAL(0);
            qsort_send(false);  //ARM
            GET_TIME_VAL(1);
            ui->textBrowser->append("End of the  Qsort ARM simulation..");
             fprintf(as2cbench,"End of the  Qsort ARM simulation..\n");

            sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
            ui->textBrowser->append(szText);
             fprintf(as2cbench,szText);

    }




}
