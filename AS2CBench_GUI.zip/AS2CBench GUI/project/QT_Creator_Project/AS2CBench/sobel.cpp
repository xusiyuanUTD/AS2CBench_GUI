#include "define.h"

   //variables
  unsigned char *bitmapData;
  unsigned char  *bitmapFinalImage;
  FILE *ifptr, *ofptr, *diffptr;
  BITMAPINFOHEADER bitmapInfoHeader;
  BITMAPFILEHEADER bitmapFileHeader; //our bitmap file header
  unsigned char biColourPalette[1024];

unsigned int line_buffer[SIZE_BUFFER][SIZE_BUFFER];



unsigned int MainWindow::sobel_filter(unsigned int *input_row_r)
{

  unsigned int X, Y;
  unsigned int orow;
  int sumX, sumY;
  int SUM, rowOffset, colOffset;



  int Gx[3][3] ={{-1 ,-2 ,-1},
          { 0, 0, 0},
          { +1, 2, +1}};


  int Gy[3][3] ={{-1, 0, 1},
 {-2, 0, 2},
 {-1, 0, 1}};


  /* Shifting 3x3 line buffer by one row  */

   for(Y=2;Y>0;Y--){
     for(X=0;X< 3;X++){
       line_buffer[Y][X]=line_buffer[Y-1][X];
     }
   }

   // Reading new data into the line buffer
   for(X=0; X<SIZE_BUFFER; X++)
     line_buffer[0][X] = input_row_r[X];



   Y=1;
   X=1;
   sumX = 0;
   sumY = 0;

   // Convolution starts here
   //-------X GRADIENT APPROXIMATION------
   //-------Y GRADIENT APPROXIMATION------
   for(rowOffset = -1; rowOffset <= 1; rowOffset++){
     for(colOffset = -1; colOffset <=1; colOffset++){
       sumX = sumX + line_buffer[Y -rowOffset][X+colOffset] * Gx[1+rowOffset][1+colOffset];
       sumY = sumY + line_buffer[Y -rowOffset][X+colOffset] * Gy[1+rowOffset][1+colOffset];
    }
    }


      if(sumX > 255)    sumX = 255;
      else if(sumX < 0) sumX = 0;

      if(sumY > 255)    sumY = 255;
      else if(sumY < 0) sumY = 0;


      SUM = sumX + sumY;

      if(SUM > 255)    SUM = 255;
         else if(SUM < 0) SUM = 0;

      orow = 255  - (SUM);
      return (orow);

}

//--------------------------
//  Bitmap loading function
//--------------------------

unsigned char * MainWindow::load_bitmapfile(const char *image)
{

  unsigned char *bitmapImage;
 // int l;

 // Open bmp file to be filtered
  ifptr = fopen(image,"rb");
  if(!ifptr){
       exit(-1);
  }


  if(ifptr == NULL){
    exit (-1);
  }

 fread(&bitmapFileHeader, sizeof(BITMAPFILEHEADER),1,ifptr);



 if (bitmapFileHeader.bfType !=0x4D42)
    {
        fclose(ifptr);

    }

 // Read the bitmap info header
 fread(&bitmapInfoHeader, sizeof(BITMAPINFOHEADER),1,ifptr);

 // Read colour palette
 fread(&biColourPalette,1,bitmapInfoHeader.biClrUsed*4,ifptr);



    //move file point to the begging of bitmap data
    fseek(ifptr, bitmapFileHeader.bfOffBits, SEEK_SET);

    //allocate enough memory for the bitmap image data
    bitmapImage = (unsigned char*)malloc(SIZE);

    //verify memory allocation
    if (!bitmapImage)
      {
    free(bitmapImage);
    return NULL;
    }

    //read in the bitmap image data
    fread(bitmapImage,1, bitmapInfoHeader.biSizeImage,ifptr);

    if (bitmapImage == NULL)
      {
        return NULL;
    }


    fclose(ifptr);
    return bitmapImage;
}

//--------------------------
//  compare_results
//-------------------------

void MainWindow::sobel_compare_results(bool hwsw){

 char szText[64];
  // Variables declaration
 unsigned int j, line =0, errors=0;

  // free memory of original image which contains un-filterd image.
  if(bitmapData != NULL)
    free(bitmapData);

  // Read Golden output image data
  if(hwsw){//ARM+FPGA
  bitmapData =  load_bitmapfile(IMAGE_GOLDENHWSW);}
  else{//Pure ARM
      bitmapData =  load_bitmapfile(IMAGE_GOLDENSW);}


  //Dump the comparison result
    if(hwsw){//ARM+FPGA
    diffptr = fopen (DIFFFILENAMEHWSW, "w");}
    else {//Pure ARM
        diffptr = fopen (DIFFFILENAMESW, "w");}

    if(!diffptr){
           exit (-1);
    }


    // Main data comparison loop
  //   for(i=0;i<ROWS;i++){
   //    for(j=1;j<COLS;j++){
 for(j=3;j<(bitmapInfoHeader.biSizeImage)-3;j++){

    // bitmapData[(i*ROWS)+j];



    //   if( bitmapFinalImage[(i*ROWS)+j] !=  bitmapData[(i*ROWS)+j]){
     //    fprintf(diffptr,"\nOutput missmatch[line:%d] Golden: %x -- Output: %x",line,  bitmapData[(i*ROWS)+j],  bitmapFinalImage[(i*ROWS)+j]);
         if( bitmapFinalImage[j] !=  bitmapData[j]){
         fprintf(diffptr,"\nOutput missmatch[line:%d] Golden: %x -- Output: %x",line,  bitmapData[j],  bitmapFinalImage[j]);

         if(hwsw) sprintf(szText, "sobel(ARM+FPGA)::Output missmatch[line:%d] Golden: %x -- Output: %x",line,  bitmapData[j],  bitmapFinalImage[j]);
         else  sprintf(szText, "sobel(ARM)::Output missmatch[line:%d] Golden: %x -- Output: %x",line,  bitmapData[j],  bitmapFinalImage[j]);
         ui->textBrowser->append(szText);

         errors++;
       }

          line ++;

     }
   //  }

 if(errors == 0){
    if(hwsw)  ui->textBrowser->append("Finished Sobel Filter ARM+FPGA simulation SUCCESSFULLY !! " );
    else  ui->textBrowser->append("Finished Sobel Filter Pure ARM simulation SUCCESSFULLY !! " );
 }

 else{

     if(hwsw) sprintf(szText, "sobel(ARM+FPGA)::MISMATCH :: %u out of %u ",errors,line);
     else sprintf(szText, "sobel(ARM)::MISMATCH :: %u out of %u ",errors,line);
     ui->textBrowser->append(szText);




 }


    fclose(diffptr);

}
/*
 ** Create new BMP file for filter results
*/


void MainWindow::sobel_image_write(void){

  // Variables declaration
  int i,j,bytesperline,n;
  int l,k;
  unsigned char  *tk;




 k=sizeof(BITMAPFILEHEADER);
 l=sizeof(BITMAPINFOHEADER);


 bytesperline = bitmapInfoHeader.biWidth * BYTES_PER_PIXEL; // multiply by 3 only for 24 bit images


 if( bytesperline & 0x0003)
   {  bytesperline |= 0x0003;
     ++bytesperline;}



 tk = (unsigned char  *)calloc(1,bytesperline);
 bitmapFileHeader.bfSize= bitmapInfoHeader.biSize + (long)bytesperline* bitmapInfoHeader.biHeight;

 bitmapFileHeader.bfOffBits = k+l+ 4* bitmapInfoHeader.biClrUsed;
 bitmapFileHeader.bfSize = k+l+bitmapInfoHeader.biSizeImage;


 n=0;



 if(ofptr!=NULL){
   fwrite(&bitmapFileHeader,1,sizeof(BITMAPFILEHEADER),ofptr);
   fwrite(&bitmapInfoHeader,1,sizeof(BITMAPINFOHEADER),ofptr);
   fwrite(biColourPalette,bitmapInfoHeader.biClrUsed*4,1,ofptr);



   for(i=(bitmapInfoHeader.biHeight-1); i>=0; i--){
       for(j=0;j<=(bytesperline)-1;j++){
       tk[j] = bitmapFinalImage[n++];
       }

       fwrite(tk,1,bytesperline,ofptr);
   }


 }
 else{
   }


 fclose(ofptr);
 free(tk);

}

//--------------------------
// Send data thread
//-------------------------

void MainWindow::sobel_send(bool hwsw){ //0:ARM 1:ARM+FPGA


  // Variables declration
    static int i,j,k;
   unsigned int input_row_write[3];
 // variablesd declaration
    int read;



  for(i=0;i<3;i++) input_row_write[i]=0;




  // Initialization



  i=0;
  j=0;


  bitmapFinalImage = (unsigned char *)malloc(SIZE);
  if (!bitmapFinalImage)
    {
      free(bitmapFinalImage);
       }


  //open file for writing

   if( (index.compare("Default File")==0) | (index.compare("Select File...")==0)) {//open file

 if(index.compare("Default File")==0) {//open file
       bitmapData =  load_bitmapfile(IMAGE_IN); }
 else {

     bitmapData =  load_bitmapfile(ui->textEdit_sobel->toPlainText().toLatin1().data());
 }

         ui->progressBar->setRange(0,ROWS*(ROWS-1)+COLS-1);




  if(hwsw){//ARM+FPGA
    ofptr=fopen(IMAGE_OUTHWSW,"wb");  }
  else{//ARM+FPGA
      ofptr=fopen(IMAGE_OUTSW,"wb");  }


    // Send Image data to sobel filter
     for(i=0;i<ROWS;i++){
         for(j=1;j<COLS;j++){
       for(k=j-1;k<=j+1;k++){

         // Send triplets at a time
         if(k==j-1){
           input_row_write[0] = bitmapData[(i*ROWS)+k];

        if(hwsw) alt_write_word(h2p_lw_UUT_addr,input_row_write[0]);

         }
         else if(k==j){
           input_row_write[1] = bitmapData[(i*ROWS)+k];

        if(hwsw) alt_write_word(h2p_lw_UUT_addr,input_row_write[1]);

         }
         else{
           input_row_write[2]= bitmapData[(i*ROWS)+k];

        if(hwsw) alt_write_word(h2p_lw_UUT_addr,input_row_write[2]);

         }
       }

   if(hwsw) {

    while(1){

    read=alt_read_word(h2p_lw_outvalid_addr);

    if(read==1)
    {
    alt_write_word(h2p_lw_outvalid_addr,true);
    bitmapFinalImage[(i*ROWS)+j]=alt_read_word(h2p_lw_UUT_addr);
    break;
    }}

   }
   else
   {
     bitmapFinalImage[(i*ROWS)+j] =  sobel_filter(input_row_write); }


    ui->progressBar->setValue((i*ROWS)+j);


     }


 }

     ui->progressBar->setValue(ROWS*(ROWS-1)+COLS-1);

     if(index.compare("Default File")==0) {//open file
   if(hwsw){

     sobel_compare_results(true);}

    else{

     sobel_compare_results(false);}    }



   sobel_image_write();  }



   else if(index.compare("Random")==0) {//open file --- don't need to compare



             ui->progressBar->setRange(0,index_val-1);



       for(unsigned long index_xx=0;index_xx<index_val;index_xx++) {

           ui->progressBar->setValue(index_xx);


         if(hwsw) {

             for(int index_yy=0;index_yy<3;index_yy++){
             alt_write_word(h2p_lw_UUT_addr,rand()%255);}

          while(1){
          read=alt_read_word(h2p_lw_outvalid_addr);
          if(read==1)
          {
          alt_write_word(h2p_lw_outvalid_addr,true);
          bitmapFinalImage[(i*ROWS)+j]=alt_read_word(h2p_lw_UUT_addr);
          break;
          }}

         }
         else
         {
           input_row_write[0]=rand()%255;
           input_row_write[1]=rand()%255;
           input_row_write[2]=rand()%255;
           bitmapFinalImage[index_xx] =  sobel_filter(input_row_write); }

       //  qDebug()<< input_row_write[0] <<"\t" << input_row_write[1] <<"\t"<< input_row_write[2] <<"\n";
       //  qDebug()<< "output is "<< bitmapFinalImage[index_xx] ;



       }



   }





}

/*
void MainWindow::sobel_random(bool hwsw)

{
    for(int i=0;i<100;i++)
        ui->textBrowser->append("")


}
*/

void MainWindow::sobel_main(bool hwsw,bool single_double) //0:ARM  1:ARM+FPGA
{

    void *virtual_base;
    int fd;
    QPixmap pixmap;
    GET_TIME_INIT(3);
    char szText[64];
    double compare_t[2];
    double compare_bool;



   if(hwsw){//ARM+FPGA

    // map the address space for the LED registers into user space so we can interact with them.
    // we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
    if( ( fd = ::open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );

    }
    virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        ::close( fd );

    }
    h2p_lw_UUT_addr=(uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_0_BASE) & ( unsigned long)( HW_REGS_MASK ) );
    h2p_lw_outvalid_addr=(uint8_t  *)virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + VALID_OUT_0_BASE ) & ( unsigned long)( HW_REGS_MASK ) );

    if(single_double){ //two version

        ui->textBrowser->append("Start the  Sobel Filter simulation...");
              fprintf(as2cbench,"Start the  Sobel Filter simulation...\n");


       // if(index.compare("Default File")==0) pixmap.load(":/new/image/image/lena512.bmp" );
       // else {
          if((index.compare("Default File")==0 )| (index.compare("Select File...")==0)) {
        sprintf(szText,"./%s",ui->textEdit_sobel->toPlainText().toLatin1().data());
        pixmap.load(szText);
      //  }
          pixmap=pixmap.scaled(150,150,Qt::KeepAspectRatio);
        ui->label_bmpin->setPixmap( pixmap );

    }
        GET_TIME_VAL(0);
        sobel_send(false);  //ARM
        GET_TIME_VAL(1);
        sobel_send(true);  //ARM+FPGA
        GET_TIME_VAL(2);

        compare_t[0]=(TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0;
        compare_t[1]=(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0;

        compare_bool=(compare_t[0]-compare_t[1])/compare_t[0];
        compare_bool=(compare_bool*100); //==> 100%

      // if(index.compare("Default File")==0)   pixmap.load(":/new/image/image/lena512_out.bmp" );
       //else {
         if((index.compare("Default File")==0 )| (index.compare("Select File...")==0)) {
        if(strcmp(ui->textEdit_sobel->toPlainText().toLatin1().data(),"lena512.bmp")==0) pixmap.load(":/new/image/image/lena512_out.bmp" );
        else if (strcmp(ui->textEdit_sobel->toPlainText().toLatin1().data(),"barbara.bmp")==0) pixmap.load(":/new/image/image/barbara_out.bmp" );


       pixmap=pixmap.scaled(150,150,Qt::KeepAspectRatio);
        ui->label_bmpout->setPixmap( pixmap );

         }

        ui->textBrowser->append("End of the  Sobel Filter simulation..");
        ui->textBrowser->append("  ");
        ui->textBrowser->append(" Sobel Simulation Results: ");
        ui->textBrowser->append(" -------------------------------------------- ");
        ui->textBrowser->append("   Pure ARM     ||     ARM+FPGA  : ");
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" -------------------------------------------- ");
        sprintf(szText, "Sobel Accelerated %0.2lf%%",compare_bool);
        ui->textBrowser->append(szText);
        ui->textBrowser->append(" -------------------------------------------- ");

        fprintf(as2cbench,"End of the  Sobel Filter simulation..\n");
        fprintf(as2cbench,"  \n");
        fprintf(as2cbench,"  Sobel Simulation Results: \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        fprintf(as2cbench,"   Pure ARM     ||     ARM+FPGA  : \n");
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "%0.3lf second   ||      %0.3lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0,(TIME_VAL_TO_MS(2)-TIME_VAL_TO_MS(1))/1000.0);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," -------------------------------------------- \n");
        sprintf(szText, "Sobel Accelerated %0.2lf%%\n",compare_bool);
        fprintf(as2cbench,szText);
        fprintf(as2cbench," ----------------------------------------------------------- \n");
    }
      else{
    ui->textBrowser->append("Start the ARM+FPGA Sobel Filter simulation...");
    fprintf(as2cbench,"Start the ARM+FPGA Sobel Filter simulation...\n");
    if(index.compare("Default File")==0) pixmap.load(":/new/image/image/lena512.bmp" );
    else {
    sprintf(szText,"./%s",ui->textEdit_sobel->toPlainText().toLatin1().data());
    pixmap.load(szText);
    }
    if((index.compare("Default File")==0)| (index.compare("Select File...")==0)) pixmap=pixmap.scaled(150,150,Qt::KeepAspectRatio);
    if((index.compare("Default File")==0 )| (index.compare("Select File...")==0)) ui->label_bmpin->setPixmap( pixmap );
   //qDebug()<<"FPGA wrong!\r\n";
    GET_TIME_VAL(0);
    sobel_send(true);  //ARM+FPGA
    GET_TIME_VAL(1);
     if(index.compare("Default File")==0 ) pixmap.load(":/new/image/image/lena512_out.bmp" );
     else {
      if(strcmp(ui->textEdit_sobel->toPlainText().toLatin1().data(),"lena512.bmp")==0) pixmap.load(":/new/image/image/lena512_out.bmp" );
      else if (strcmp(ui->textEdit_sobel->toPlainText().toLatin1().data(),"barbara.bmp")==0) pixmap.load(":/new/image/image/barbara_out.bmp" );

     }
     if((index.compare("Default File")==0 )| (index.compare("Select File...")==0)) pixmap=pixmap.scaled(150,150,Qt::KeepAspectRatio);
     if((index.compare("Default File")==0 )| (index.compare("Select File...")==0)) ui->label_bmpout->setPixmap( pixmap );
    ui->textBrowser->append("End of the ARM+FPGA Sobel Filter simulation..");
    fprintf(as2cbench,"End of the ARM+FPGA Sobel Filter simulation..\n");
    sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
    ui->textBrowser->append(szText);
     fprintf(as2cbench,szText);
    }

   }
   else  //Pure ARM
   {
       ui->textBrowser->append("Start the Pure ARM Sobel Filter simulation...");
       fprintf(as2cbench,"Start the Pure ARM Sobel Filter simulation...\n");
        if(index.compare("Default File")==0)  pixmap.load(":/new/image/image/lena512.bmp" );
        else {
        sprintf(szText,"./%s",ui->textEdit_sobel->toPlainText().toLatin1().data());
        pixmap.load(szText);
        }
        if((index.compare("Default File")==0 )| (index.compare("Select File...")==0)) pixmap=pixmap.scaled(150,150,Qt::KeepAspectRatio);
        if((index.compare("Default File")==0 )| (index.compare("Select File...")==0)) ui->label_bmpin->setPixmap( pixmap );
      //qDebug()<<"FPGA wrong!\r\n";
       GET_TIME_VAL(0);
       sobel_send(false);  //ARM
       GET_TIME_VAL(1);
        if(index.compare("Default File")==0) pixmap.load(":/new/image/image/lena512_out.bmp" );
        else {
         if(strcmp(ui->textEdit_sobel->toPlainText().toLatin1().data(),"lena512.bmp")==0) pixmap.load(":/new/image/image/lena512_out.bmp" );
         else if (strcmp(ui->textEdit_sobel->toPlainText().toLatin1().data(),"barbara.bmp")==0) pixmap.load(":/new/image/image/barbara_out.bmp" );

        }
        if((index.compare("Default File")==0 )| (index.compare("Select File...")==0) ) pixmap=pixmap.scaled(150,150,Qt::KeepAspectRatio);

        if((index.compare("Default File")==0 )|(index.compare("Select File...")==0) )  ui->label_bmpout->setPixmap( pixmap );


       ui->textBrowser->append("End of the Pure ARM Sobel Filter simulation..");
              fprintf(as2cbench,"End of the Pure ARM Sobel Filter simulation..\n");
       sprintf(szText, "Running time %10.4lf second\n", (TIME_VAL_TO_MS(1)-TIME_VAL_TO_MS(0))/1000.0);
       ui->textBrowser->append(szText);
        fprintf(as2cbench,szText);
   }



   if(hwsw){

    if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
        printf( "ERROR: munmap() failed...\n" );
        ::close( fd );
    }
    ::close( fd );
     //qDebug()<<"Finished";

   }





}






