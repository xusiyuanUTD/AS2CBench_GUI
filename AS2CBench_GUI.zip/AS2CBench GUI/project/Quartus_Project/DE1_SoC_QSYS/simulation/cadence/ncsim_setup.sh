
# (C) 2001-2015 Altera Corporation. All rights reserved.
# Your use of Altera Corporation's design tools, logic functions and 
# other software and tools, and its AMPP partner logic functions, and 
# any output files any of the foregoing (including device programming 
# or simulation files), and any associated documentation or information 
# are expressly subject to the terms and conditions of the Altera 
# Program License Subscription Agreement, Altera MegaCore Function 
# License Agreement, or other applicable license agreement, including, 
# without limitation, that your use is for the sole purpose of 
# programming logic devices manufactured by Altera and sold by Altera 
# or its authorized distributors. Please refer to the applicable 
# agreement for further details.

# ACDS 14.1 186 win32 2015.12.08.08:29:07

# ----------------------------------------
# ncsim - auto-generated simulation script

# ----------------------------------------
# initialize variables
TOP_LEVEL_NAME="DE1_SoC_QSYS"
QSYS_SIMDIR="./../"
QUARTUS_INSTALL_DIR="F:/altera/14.1/quartus/"
SKIP_FILE_COPY=0
SKIP_DEV_COM=0
SKIP_COM=0
SKIP_ELAB=0
SKIP_SIM=0
USER_DEFINED_ELAB_OPTIONS=""
USER_DEFINED_SIM_OPTIONS="-input \"@run 100; exit\""

# ----------------------------------------
# overwrite variables - DO NOT MODIFY!
# This block evaluates each command line argument, typically used for 
# overwriting variables. An example usage:
#   sh <simulator>_setup.sh SKIP_ELAB=1 SKIP_SIM=1
for expression in "$@"; do
  eval $expression
  if [ $? -ne 0 ]; then
    echo "Error: This command line argument, \"$expression\", is/has an invalid expression." >&2
    exit $?
  fi
done

# ----------------------------------------
# initialize simulation properties - DO NOT MODIFY!
ELAB_OPTIONS=""
SIM_OPTIONS=""
if [[ `ncsim -version` != *"ncsim(64)"* ]]; then
  :
else
  :
fi

# ----------------------------------------
# create compilation libraries
mkdir -p ./libraries/work/
mkdir -p ./libraries/sdram/
mkdir -p ./libraries/pll_sys/
mkdir -p ./libraries/pll_audio/
mkdir -p ./libraries/onchip_memory2/
mkdir -p ./libraries/ledr/
mkdir -p ./libraries/key/
mkdir -p ./libraries/jtag_uart/
mkdir -p ./libraries/ir_rx/
mkdir -p ./libraries/i2c_sda/
mkdir -p ./libraries/i2c_scl/
mkdir -p ./libraries/hps_0/
mkdir -p ./libraries/cpu/
mkdir -p ./libraries/clock_crossing_io_slow/
mkdir -p ./libraries/audio/
mkdir -p ./libraries/alt_vip_vfr_0/
mkdir -p ./libraries/alt_vip_vfb_0/
mkdir -p ./libraries/alt_vip_mix_0/
mkdir -p ./libraries/alt_vip_itc_0/
mkdir -p ./libraries/alt_vip_dil_0/
mkdir -p ./libraries/alt_vip_cti_0/
mkdir -p ./libraries/alt_vip_csc_0/
mkdir -p ./libraries/alt_vip_crs_0/
mkdir -p ./libraries/alt_vip_cpr_2/
mkdir -p ./libraries/alt_vip_cpr_1/
mkdir -p ./libraries/alt_vip_cpr_0/
mkdir -p ./libraries/alt_vip_clip_0/
mkdir -p ./libraries/alt_vip_cl_scl_0/
mkdir -p ./libraries/altera_ver/
mkdir -p ./libraries/lpm_ver/
mkdir -p ./libraries/sgate_ver/
mkdir -p ./libraries/altera_mf_ver/
mkdir -p ./libraries/altera_lnsim_ver/
mkdir -p ./libraries/cyclonev_ver/
mkdir -p ./libraries/cyclonev_hssi_ver/
mkdir -p ./libraries/cyclonev_pcie_hip_ver/

# ----------------------------------------
# copy RAM/ROM files to simulation directory
if [ $SKIP_FILE_COPY -eq 0 ]; then
  cp -f $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_onchip_memory2.hex ./
  cp -f $QSYS_SIMDIR/submodules/tta_x_blank_mem.hex ./
  cp -f $QSYS_SIMDIR/submodules/de1_soc_qsys_alt_vip_csc_0_coeff_data_init_id_1061_line160_contents.hex ./
  cp -f $QSYS_SIMDIR/submodules/de1_soc_qsys_alt_vip_csc_0_const_data_init_id_1071_line161_contents.hex ./
fi

# ----------------------------------------
# compile device library files
if [ $SKIP_DEV_COM -eq 0 ]; then
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives.v"                      -work altera_ver           
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/220model.v"                               -work lpm_ver              
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/sgate.v"                                  -work sgate_ver            
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf.v"                              -work altera_mf_ver        
  ncvlog -sv "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_lnsim.sv"                          -work altera_lnsim_ver     
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cadence/cyclonev_atoms_ncrypt.v"          -work cyclonev_ver         
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cadence/cyclonev_hmi_atoms_ncrypt.v"      -work cyclonev_ver         
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_atoms.v"                         -work cyclonev_ver         
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cadence/cyclonev_hssi_atoms_ncrypt.v"     -work cyclonev_hssi_ver    
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_hssi_atoms.v"                    -work cyclonev_hssi_ver    
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cadence/cyclonev_pcie_hip_atoms_ncrypt.v" -work cyclonev_pcie_hip_ver
  ncvlog     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_pcie_hip_atoms.v"                -work cyclonev_pcie_hip_ver
fi

# ----------------------------------------
# compile design files in correct order
if [ $SKIP_COM -eq 0 ]; then
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_sdram.v"                           -work sdram                  -cdslib ./cds_libs/sdram.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_sdram_test_component.v"            -work sdram                  -cdslib ./cds_libs/sdram.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_pll_sys.vo"                        -work pll_sys                -cdslib ./cds_libs/pll_sys.cds.lib               
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_pll_audio.vo"                      -work pll_audio              -cdslib ./cds_libs/pll_audio.cds.lib             
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_onchip_memory2.v"                  -work onchip_memory2         -cdslib ./cds_libs/onchip_memory2.cds.lib        
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_ledr.v"                            -work ledr                   -cdslib ./cds_libs/ledr.cds.lib                  
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_key.v"                             -work key                    -cdslib ./cds_libs/key.cds.lib                   
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_jtag_uart.v"                       -work jtag_uart              -cdslib ./cds_libs/jtag_uart.cds.lib             
  ncvlog     "$QSYS_SIMDIR/submodules/TERASIC_IR_RX_FIFO.v"                           -work ir_rx                  -cdslib ./cds_libs/ir_rx.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/irda_receive_terasic.v"                         -work ir_rx                  -cdslib ./cds_libs/ir_rx.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/ir_fifo.v"                                      -work ir_rx                  -cdslib ./cds_libs/ir_rx.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_i2c_sda.v"                         -work i2c_sda                -cdslib ./cds_libs/i2c_sda.cds.lib               
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_i2c_scl.v"                         -work i2c_scl                -cdslib ./cds_libs/i2c_scl.cds.lib               
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_hps_0.v"                           -work hps_0                  -cdslib ./cds_libs/hps_0.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_cpu.v"                             -work cpu                    -cdslib ./cds_libs/cpu.cds.lib                   
  ncvlog     "$QSYS_SIMDIR/submodules/altera_avalon_mm_clock_crossing_bridge.v"       -work clock_crossing_io_slow -cdslib ./cds_libs/clock_crossing_io_slow.cds.lib
  ncvlog     "$QSYS_SIMDIR/submodules/altera_avalon_dc_fifo.v"                        -work clock_crossing_io_slow -cdslib ./cds_libs/clock_crossing_io_slow.cds.lib
  ncvlog     "$QSYS_SIMDIR/submodules/altera_dcfifo_synchronizer_bundle.v"            -work clock_crossing_io_slow -cdslib ./cds_libs/clock_crossing_io_slow.cds.lib
  ncvlog     "$QSYS_SIMDIR/submodules/altera_std_synchronizer_nocut.v"                -work clock_crossing_io_slow -cdslib ./cds_libs/clock_crossing_io_slow.cds.lib
  ncvlog     "$QSYS_SIMDIR/submodules/AUDIO_IF.v"                                     -work audio                  -cdslib ./cds_libs/audio.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/AUDIO_ADC.v"                                    -work audio                  -cdslib ./cds_libs/audio.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/AUDIO_DAC.v"                                    -work audio                  -cdslib ./cds_libs/audio.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/audio_fifo.v"                                   -work audio                  -cdslib ./cds_libs/audio.cds.lib                 
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_vfr_0.vo"                  -work alt_vip_vfr_0          -cdslib ./cds_libs/alt_vip_vfr_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_vfb_0.vo"                  -work alt_vip_vfb_0          -cdslib ./cds_libs/alt_vip_vfb_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_mix_0.vo"                  -work alt_vip_mix_0          -cdslib ./cds_libs/alt_vip_mix_0.cds.lib         
  ncvlog -sv "$QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid.sv"                        -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_sync_compare.v"            -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_calculate_mode.v"          -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_control.v"                 -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog -sv "$QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_mode_banks.sv"             -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_statemachine.v"            -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_common_fifo.v"                    -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_common_generic_count.v"           -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_common_to_binary.v"               -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_common_sync.v"                    -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_common_trigger_sync.v"            -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_common_sync_generation.v"         -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_common_frame_counter.v"           -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipitc131_common_sample_counter.v"          -work alt_vip_itc_0          -cdslib ./cds_libs/alt_vip_itc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_dil_0.vo"                  -work alt_vip_dil_0          -cdslib ./cds_libs/alt_vip_dil_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS.v"                         -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_control.v"                 -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_av_st_output.v"            -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_resolution_detection.v"    -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_write_buffer.v"            -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_embedded_sync_extractor.v" -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_sync_polarity_convertor.v" -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_common_fifo.v"                    -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_common_sync.v"                    -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_common_sync_generation.v"         -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_common_frame_counter.v"           -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/alt_vipcti131_common_sample_counter.v"          -work alt_vip_cti_0          -cdslib ./cds_libs/alt_vip_cti_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_csc_0.vo"                  -work alt_vip_csc_0          -cdslib ./cds_libs/alt_vip_csc_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_crs_0.vo"                  -work alt_vip_crs_0          -cdslib ./cds_libs/alt_vip_crs_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_cpr_2.vo"                  -work alt_vip_cpr_2          -cdslib ./cds_libs/alt_vip_cpr_2.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_cpr_1.vo"                  -work alt_vip_cpr_1          -cdslib ./cds_libs/alt_vip_cpr_1.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_cpr_0.vo"                  -work alt_vip_cpr_0          -cdslib ./cds_libs/alt_vip_cpr_0.cds.lib         
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_clip_0.vo"                 -work alt_vip_clip_0         -cdslib ./cds_libs/alt_vip_clip_0.cds.lib        
  ncvlog     "$QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_cl_scl_0.v"                -work alt_vip_cl_scl_0       -cdslib ./cds_libs/alt_vip_cl_scl_0.cds.lib      
  ncvlog     "$QSYS_SIMDIR/DE1_SoC_QSYS.v"                                                                                                                          
fi

# ----------------------------------------
# elaborate top level design
if [ $SKIP_ELAB -eq 0 ]; then
  ncelab -access +w+r+c -namemap_mixgen $ELAB_OPTIONS $USER_DEFINED_ELAB_OPTIONS $TOP_LEVEL_NAME
fi

# ----------------------------------------
# simulate
if [ $SKIP_SIM -eq 0 ]; then
  eval ncsim -licqueue $SIM_OPTIONS $USER_DEFINED_SIM_OPTIONS $TOP_LEVEL_NAME
fi
