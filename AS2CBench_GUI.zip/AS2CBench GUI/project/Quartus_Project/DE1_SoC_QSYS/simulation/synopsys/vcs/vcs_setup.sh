
# (C) 2001-2015 Altera Corporation. All rights reserved.
# Your use of Altera Corporation's design tools, logic functions and 
# other software and tools, and its AMPP partner logic functions, and 
# any output files any of the foregoing (including device programming 
# or simulation files), and any associated documentation or information 
# are expressly subject to the terms and conditions of the Altera 
# Program License Subscription Agreement, Altera MegaCore Function 
# License Agreement, or other applicable license agreement, including, 
# without limitation, that your use is for the sole purpose of 
# programming logic devices manufactured by Altera and sold by Altera 
# or its authorized distributors. Please refer to the applicable 
# agreement for further details.

# ACDS 14.1 186 win32 2015.12.08.08:29:07

# ----------------------------------------
# vcs - auto-generated simulation script

# ----------------------------------------
# initialize variables
TOP_LEVEL_NAME="DE1_SoC_QSYS"
QSYS_SIMDIR="./../../"
QUARTUS_INSTALL_DIR="F:/altera/14.1/quartus/"
SKIP_FILE_COPY=0
SKIP_ELAB=0
SKIP_SIM=0
USER_DEFINED_ELAB_OPTIONS=""
USER_DEFINED_SIM_OPTIONS="+vcs+finish+100"
# ----------------------------------------
# overwrite variables - DO NOT MODIFY!
# This block evaluates each command line argument, typically used for 
# overwriting variables. An example usage:
#   sh <simulator>_setup.sh SKIP_ELAB=1 SKIP_SIM=1
for expression in "$@"; do
  eval $expression
  if [ $? -ne 0 ]; then
    echo "Error: This command line argument, \"$expression\", is/has an invalid expression." >&2
    exit $?
  fi
done

# ----------------------------------------
# initialize simulation properties - DO NOT MODIFY!
ELAB_OPTIONS=""
SIM_OPTIONS=""
if [[ `vcs -platform` != *"amd64"* ]]; then
  :
else
  :
fi

# ----------------------------------------
# copy RAM/ROM files to simulation directory
if [ $SKIP_FILE_COPY -eq 0 ]; then
  cp -f $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_onchip_memory2.hex ./
  cp -f $QSYS_SIMDIR/submodules/tta_x_blank_mem.hex ./
  cp -f $QSYS_SIMDIR/submodules/de1_soc_qsys_alt_vip_csc_0_coeff_data_init_id_1061_line160_contents.hex ./
  cp -f $QSYS_SIMDIR/submodules/de1_soc_qsys_alt_vip_csc_0_const_data_init_id_1071_line161_contents.hex ./
fi

vcs -lca -timescale=1ps/1ps -sverilog +verilog2001ext+.v -ntb_opts dtm $ELAB_OPTIONS $USER_DEFINED_ELAB_OPTIONS \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/220model.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/sgate.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf.v \
  $QUARTUS_INSTALL_DIR/eda/sim_lib/altera_lnsim.sv \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/cyclonev_atoms_ncrypt.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/cyclonev_hmi_atoms_ncrypt.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_atoms.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/cyclonev_hssi_atoms_ncrypt.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_hssi_atoms.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/cyclonev_pcie_hip_atoms_ncrypt.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_pcie_hip_atoms.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_sdram.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_sdram_test_component.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_pll_sys.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_pll_audio.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_onchip_memory2.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_ledr.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_key.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_jtag_uart.v \
  $QSYS_SIMDIR/submodules/TERASIC_IR_RX_FIFO.v \
  $QSYS_SIMDIR/submodules/irda_receive_terasic.v \
  $QSYS_SIMDIR/submodules/ir_fifo.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_i2c_sda.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_i2c_scl.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_hps_0.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_cpu.v \
  $QSYS_SIMDIR/submodules/altera_avalon_mm_clock_crossing_bridge.v \
  $QSYS_SIMDIR/submodules/altera_avalon_dc_fifo.v \
  $QSYS_SIMDIR/submodules/altera_dcfifo_synchronizer_bundle.v \
  $QSYS_SIMDIR/submodules/altera_std_synchronizer_nocut.v \
  $QSYS_SIMDIR/submodules/AUDIO_IF.v \
  $QSYS_SIMDIR/submodules/AUDIO_ADC.v \
  $QSYS_SIMDIR/submodules/AUDIO_DAC.v \
  $QSYS_SIMDIR/submodules/audio_fifo.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_vfr_0.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_vfb_0.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_mix_0.vo \
  $QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid.sv \
  $QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_sync_compare.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_calculate_mode.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_control.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_mode_banks.sv \
  $QSYS_SIMDIR/submodules/alt_vipitc131_IS2Vid_statemachine.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_common_fifo.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_common_generic_count.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_common_to_binary.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_common_sync.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_common_trigger_sync.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_common_sync_generation.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_common_frame_counter.v \
  $QSYS_SIMDIR/submodules/alt_vipitc131_common_sample_counter.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_dil_0.vo \
  $QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_control.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_av_st_output.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_resolution_detection.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_write_buffer.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_embedded_sync_extractor.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_Vid2IS_sync_polarity_convertor.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_common_fifo.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_common_sync.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_common_sync_generation.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_common_frame_counter.v \
  $QSYS_SIMDIR/submodules/alt_vipcti131_common_sample_counter.v \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_csc_0.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_crs_0.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_cpr_2.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_cpr_1.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_cpr_0.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_clip_0.vo \
  $QSYS_SIMDIR/submodules/DE1_SoC_QSYS_alt_vip_cl_scl_0.v \
  $QSYS_SIMDIR/DE1_SoC_QSYS.v \
  -top $TOP_LEVEL_NAME
# ----------------------------------------
# simulate
if [ $SKIP_SIM -eq 0 ]; then
  ./simv $SIM_OPTIONS $USER_DEFINED_SIM_OPTIONS
fi
